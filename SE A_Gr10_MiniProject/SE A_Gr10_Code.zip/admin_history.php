<?php
session_start();
include 'db_connect.php';
if ($_SESSION['user_role'] != 'admin') header("Location: index.php");

// INITIALIZE VARIABLES
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

// LOGIC: If Searching, ignore Date. If not Searching, use Date.
if (!empty($search)) {
    // --- SEARCH MODE ---
    $where_clause = "orders.order_code LIKE '%$search%'";
    $page_title = "Search Results: '$search'";
} else {
    // --- DATE MODE (Default) ---
    $where_clause = "DATE(orders.order_date) = '$date'";
    $page_title = "History: " . date("d M Y", strtotime($date));
}

// 1. FETCH STATS (Based on current view)
$total_day = $conn->query("SELECT COUNT(*) FROM orders WHERE $where_clause")->fetch_row()[0];
$income_day = $conn->query("SELECT SUM(total_price) FROM orders WHERE $where_clause AND status='Collected'")->fetch_row()[0] ?? 0;

// 2. FETCH ORDERS WITH DETAILED ITEMS
$sql = "SELECT orders.*, users.full_name, users.phone,
        (SELECT GROUP_CONCAT(CONCAT(item_name, '::', quantity, '::', price) SEPARATOR '||') FROM order_details WHERE order_id = orders.id) as item_details,
        (SELECT GROUP_CONCAT(CONCAT(item_name, ' (x', quantity, ')') SEPARATOR ', ') FROM order_details WHERE order_id = orders.id) as plain_items
        FROM orders 
        LEFT JOIN users ON orders.moodle_id = users.moodle_id 
        WHERE $where_clause 
        ORDER BY orders.id DESC";
$orders = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Order History | Campus Dine</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    
    <style>
        body { background-color: #f4f6f9; transition: background-color 0.3s, color 0.3s; }
        
        /* Table enhancements */
        .table-custom { border-radius: 16px; overflow: hidden; }
        .table-custom th { background-color: #333; color: #fff; font-weight: 600; border: none; padding: 15px; }
        .table-custom td { padding: 15px; vertical-align: middle; border-bottom: 1px solid #f0f0f0; }
        
        /* Professional Minimalist Receipt Styles */
        .professional-receipt { border-radius: 12px; border: 1px solid #e0e0e0; }
        .receipt-header { text-align: center; border-bottom: 2px dashed #e0e0e0; padding-bottom: 20px; margin-bottom: 20px; }
        .receipt-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #6c757d; font-weight: 700; }
        .item-line { padding: 10px 0; border-bottom: 1px solid #f8f9fa; }
        .item-line:last-child { border-bottom: none; }

        /* STRICT PRINT RULES */
        @media print {
            @page { size: auto; margin: 10mm; }
            body, html { background-color: white !important; height: auto; }
            body * { visibility: hidden; }
            #adminReceiptModal, #adminReceiptModal * { visibility: visible; color: #000 !important; }
            #adminReceiptModal { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 0; background: white !important; }
            .modal-dialog { margin: 0 !important; max-width: 100% !important; box-shadow: none !important; border: none !important;}
            .modal-content { border: none !important; box-shadow: none !important; background-color: white !important;}
            .no-print { display: none !important; }
        }
        
        /* Dark Mode fixes specifically for Admin History table */
        body.dark-mode .table-custom td { background-color: #1e1e1e !important; color: #fff !important; border-bottom: 1px solid #333; }
        body.dark-mode .table-custom tr:hover td { background-color: #2a2a2a !important; }
    </style>
</head>
<body class="p-4">
    <div class="container-fluid max-w-1200">
        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div class="d-flex align-items-center gap-3">
                <a href="admin_panel.php" class="btn btn-outline-dark rounded-pill fw-bold shadow-sm px-4">
                    <i class="fas fa-arrow-left me-1"></i> Dashboard
                </a>
                <h4 class="mb-0 fw-bold text-dark"><i class="fas fa-history text-danger me-2"></i><?php echo $page_title; ?></h4>
            </div>
            
            <button id="darkModeToggle" class="btn btn-light rounded-pill border shadow-sm px-3 fw-bold" onclick="toggleDarkMode()" aria-label="Toggle Dark Mode">
                <i class="fas fa-moon" id="darkModeIcon"></i>
            </button>
        </div>

        <div class="card p-4 mb-4 shadow-sm border-0 rounded-4 bg-white">
            <div class="row g-3 align-items-center">
                
                <div class="col-md-5">
                    <form class="d-flex gap-2 align-items-end">
                        <div class="flex-grow-1">
                            <label class="form-label small fw-bold text-muted mb-1"><i class="far fa-calendar-alt me-1"></i> Filter by Date</label>
                            <input type="date" name="date" class="form-control rounded-pill fw-bold bg-light border-0" value="<?php echo $date; ?>">
                        </div>
                        <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold shadow-sm">Filter</button>
                    </form>
                </div>

                <div class="col-md-1 text-center d-none d-md-block text-muted fw-bold small opacity-50">OR</div>

                <div class="col-md-6">
                    <form class="d-flex gap-2 align-items-end">
                        <div class="flex-grow-1">
                            <label class="form-label small fw-bold text-muted mb-1"><i class="fas fa-search me-1"></i> Search Order ID</label>
                            <input type="text" name="search" class="form-control rounded-pill fw-bold bg-light border-0" placeholder="e.g. A7B..." value="<?php echo $search; ?>">
                        </div>
                        <button type="submit" class="btn btn-danger rounded-pill px-4 fw-bold shadow-sm" style="background-color: #D81B60; border: none;">Search</button>
                        <?php if(!empty($search)): ?>
                            <a href="admin_history.php" class="btn btn-outline-secondary rounded-pill px-3 fw-bold">Clear</a>
                        <?php endif; ?>
                    </form>
                </div>

            </div>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <div class="card p-3 text-center border-0 shadow-sm rounded-4 bg-white">
                    <h2 class="fw-bold text-dark mb-0"><?php echo $total_day; ?></h2>
                    <small class="text-muted fw-bold text-uppercase" style="letter-spacing: 1px;">Orders Found</small>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3 text-center border-0 shadow-sm rounded-4 bg-white">
                    <h2 class="fw-bold text-success mb-0">₹<?php echo $income_day; ?></h2>
                    <small class="text-muted fw-bold text-uppercase" style="letter-spacing: 1px;">Total Value</small>
                </div>
            </div>
        </div>

        <div class="table-responsive shadow-sm border-0 table-custom bg-white">
            <table class="table table-hover mb-0 text-center">
                <thead>
                    <tr>
                        <th class="py-3">Order ID</th>
                        <th class="text-start py-3 ps-4">Customer Name</th>
                        <th class="py-3">Status</th>
                        <th class="py-3">Total Paid</th>
                        <th class="py-3">Time / Date</th>
                        <th class="py-3">Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($orders->num_rows > 0): ?>
                        <?php while($row = $orders->fetch_assoc()): 
                            // Check if role is teacher
                            $is_teacher = (isset($row['role']) && $row['role'] == 'teacher');
                            $teacher_badge = $is_teacher ? "<span class='badge bg-danger rounded-pill ms-2' style='font-size:0.6rem;'><i class='fas fa-chalkboard-teacher'></i> STAFF</span>" : "";

                            // Safe Data for JS
                            $js_code  = $row['order_code'];
                            $js_name  = htmlspecialchars($row['full_name'] ?? 'Unknown', ENT_QUOTES);
                            $js_phone = htmlspecialchars($row['phone'] ?? 'N/A', ENT_QUOTES);
                            
                            // Use detailed items if available, otherwise plain items
                            $js_details = !empty($row['item_details']) ? $row['item_details'] : (!empty($row['plain_items']) ? $row['plain_items'] : $row['items']);
                            $js_details_safe = htmlspecialchars($js_details, ENT_QUOTES);
                            
                            $js_total = $row['total_price'];
                            $js_date  = date("M d, Y • h:i A", strtotime($row['order_date']));
                            $time_only= date("h:i A", strtotime($row['order_date']));
                            $date_only= date("d M Y", strtotime($row['order_date']));
                        ?>
                        <tr>
                            <td class="fw-bold text-dark align-middle">#<?php echo $row['order_code']; ?></td>
                            <td class="text-start ps-4 align-middle">
                                <div class="fw-bold text-primary"><?php echo htmlspecialchars($row['full_name']); ?> <?php echo $teacher_badge; ?></div>
                                <div class="small text-muted fw-bold"><i class="fas fa-phone-alt me-1" style="font-size: 0.7rem;"></i> <?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></div>
                            </td>
                            <td class="align-middle">
                                <span class="badge rounded-pill px-3 py-2 shadow-sm <?php echo ($row['status']=='Collected')?'bg-success':(($row['status']=='Ready')?'bg-primary':'bg-warning text-dark'); ?>">
                                    <?php echo $row['status']; ?>
                                </span>
                            </td>
                            <td class="fw-bold text-dark fs-5 align-middle">₹<?php echo $row['total_price']; ?></td>
                            <td class="align-middle">
                                <div class="fw-bold text-dark"><?php echo $time_only; ?></div>
                                <small class="text-muted fw-bold" style="font-size:0.7em;"><?php echo $date_only; ?></small>
                            </td>
                            <td class="align-middle">
                                <button class="btn btn-sm btn-dark rounded-pill px-4 fw-bold shadow-sm" 
                                    onclick="viewOrder('<?php echo $js_code; ?>', '<?php echo $js_name; ?>', '<?php echo $js_phone; ?>', '<?php echo $js_date; ?>', '<?php echo $js_details_safe; ?>', '<?php echo $js_total; ?>')">
                                    <i class="fas fa-receipt me-1"></i> Receipt
                                </button>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-muted py-5">
                                <i class="fas fa-folder-open fa-3x mb-3 opacity-25"></i>
                                <h5 class="fw-bold">No orders found</h5>
                                <p class="small">Try adjusting your date or search filter.</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="modal fade" id="adminReceiptModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 450px;">
            <div class="modal-content professional-receipt shadow-lg border-0 bg-white">
                
                <div class="modal-body p-4 bg-white" id="printableReceipt">
                    
                    <div class="receipt-header">
                        <h4 class="fw-bold mb-1 text-dark"><i class="fas fa-utensils text-danger me-2"></i>APSIT Canteen</h4>
                        <p class="text-muted small mb-0">A.P. Shah Institute of Technology</p>
                        <p class="text-muted small mb-0">Kasarvadavali, Thane West, 400615</p>
                    </div>
                    
                    <div class="row mb-4">
                        <div class="col-6 mb-3">
                            <div class="receipt-label">Order Number</div>
                            <div class="fw-bold text-dark fs-5" id="r_id">#000</div>
                        </div>
                        <div class="col-6 mb-3 text-end">
                            <div class="receipt-label">Date & Time</div>
                            <div class="fw-bold text-dark small mt-1" id="r_date">--</div>
                        </div>
                        <div class="col-6">
                            <div class="receipt-label">Customer Details</div>
                            <div class="fw-bold text-dark small mt-1" id="r_name">--</div>
                            <div class="text-muted small" id="r_phone">--</div>
                        </div>
                        <div class="col-6 text-end">
                            <div class="receipt-label">Payment Method</div>
                            <div class="fw-bold text-dark small mt-1">Online Checkout</div>
                        </div>
                    </div>

                    <div class="receipt-label border-bottom pb-2 mb-2">Order Summary</div>
                    
                    <div id="r_items" class="mb-4"></div>
                    
                    <div class="border-top pt-3">
                        <div class="d-flex justify-content-between small mb-2 text-secondary fw-bold">
                            <span>Subtotal</span>
                            <span>₹<span id="r_subtotal">0.00</span></span>
                        </div>
                        <div class="d-flex justify-content-between small mb-3 text-secondary fw-bold">
                            <span>Taxes & Convenience Fees</span>
                            <span>₹0.00</span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center bg-light p-3 rounded-3 border">
                            <span class="fw-bold text-dark text-uppercase" style="letter-spacing: 1px;">Total Paid</span>
                            <span class="fw-bold text-success fs-4">₹<span id="r_total">0.00</span></span>
                        </div>
                    </div>

                </div>
                
                <div class="modal-footer border-top-0 bg-light p-3 no-print rounded-bottom-3">
                    <button class="btn btn-outline-secondary rounded-pill px-4 fw-bold w-100 w-sm-auto mb-2 mb-sm-0 bg-white" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button class="btn btn-dark rounded-pill px-4 fw-bold w-100 w-sm-auto shadow-sm" onclick="window.print()">
                        <i class="fas fa-print me-2"></i> Print / Save PDF
                    </button>
                </div>
                
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // --- DARK MODE LOGIC ---
        const body = document.body;
        const darkModeIcon = document.getElementById('darkModeIcon');
        
        if (localStorage.getItem('darkMode') === 'enabled') {
            body.classList.add('dark-mode');
            darkModeIcon.classList.replace('fa-moon', 'fa-sun');
        }

        function toggleDarkMode() {
            body.classList.toggle('dark-mode');
            if (body.classList.contains('dark-mode')) {
                localStorage.setItem('darkMode', 'enabled');
                darkModeIcon.classList.replace('fa-moon', 'fa-sun');
            } else {
                localStorage.setItem('darkMode', 'disabled');
                darkModeIcon.classList.replace('fa-sun', 'fa-moon');
            }
        }

        // --- RECEIPT MODAL LOGIC ---
        const receiptModal = new bootstrap.Modal(document.getElementById('adminReceiptModal'));

        function viewOrder(code, name, phone, date, rawData, total) {
            document.getElementById('r_id').innerText = "#" + code;
            document.getElementById('r_name').innerText = name;
            document.getElementById('r_phone').innerText = phone;
            document.getElementById('r_date').innerText = date;
            
            let formattedTotal = parseFloat(total).toFixed(2);
            document.getElementById('r_subtotal').innerText = formattedTotal;
            document.getElementById('r_total').innerText = formattedTotal;
            
            let html = '';
            
            // LOGIC: Check if it's the detailed string (contains ::)
            if (rawData && rawData.includes('::')) {
                let itemsArray = rawData.split('||');
                
                itemsArray.forEach(itemStr => {
                    let parts = itemStr.split('::');
                    if(parts.length === 3) {
                        let itemName = parts[0];
                        let qty = parseInt(parts[1]);
                        let price = parseFloat(parts[2]);
                        let lineTotal = (qty * price).toFixed(2);
                        
                        html += `
                        <div class="item-line d-flex justify-content-between align-items-center">
                            <div>
                                <div class="fw-bold text-dark">${itemName}</div>
                                <div class="text-muted small fw-bold">₹${price.toFixed(2)} × ${qty}</div>
                            </div>
                            <div class="fw-bold text-dark">₹${lineTotal}</div>
                        </div>`;
                    }
                });
            } else {
                // FALLBACK: For older orders
                let oldItems = rawData ? rawData.split(', ') : [];
                oldItems.forEach(item => {
                    html += `
                    <div class="item-line d-flex justify-content-between align-items-center">
                        <div class="fw-bold text-dark">${item}</div>
                        <div class="text-muted small fw-bold">-</div>
                    </div>`;
                });
            }
            
            document.getElementById('r_items').innerHTML = html;
            receiptModal.show();
        }
    </script>
</body>
</html>