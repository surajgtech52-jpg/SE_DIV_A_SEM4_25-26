<?php
session_start();
include 'db_connect.php';

// Check if logged in
if (!isset($_SESSION['user_id'])) { 
    header("Location: index.php"); 
    exit(); 
}
$moodle_id = $_SESSION['user_id'];

// Fetch Orders and extract detailed item info (Name::Qty::Price) grouped by ||
$sql = "SELECT o.*, 
        (SELECT GROUP_CONCAT(CONCAT(item_name, '::', quantity, '::', price) SEPARATOR '||') 
         FROM order_details WHERE order_id = o.id) as item_details,
        (SELECT GROUP_CONCAT(CONCAT(item_name, ' (x', quantity, ')') SEPARATOR ', ') 
         FROM order_details WHERE order_id = o.id) as plain_items
        FROM orders o
        WHERE o.moodle_id = '$moodle_id' 
        ORDER BY o.id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Order History | Campus Dine</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    
    <style>
        /* Smooth transitions for dark mode toggling */
        body {
            transition: background-color 0.3s, color 0.3s;
        }

        /* Professional Minimalist Receipt Styles */
        .professional-receipt {
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }
        .receipt-header {
            text-align: center;
            border-bottom: 2px dashed #e0e0e0;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }
        .receipt-label {
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #6c757d;
            font-weight: 700;
        }
        .item-line {
            padding: 10px 0;
            border-bottom: 1px solid #f8f9fa;
        }
        .item-line:last-child {
            border-bottom: none;
        }

        /* STRICT PRINT RULES */
        @media print {
            @page { size: auto; margin: 10mm; }
            body, html { background-color: white !important; height: auto; }
            
            /* Hide EVERYTHING outside the modal */
            body * { visibility: hidden; }
            
            /* Show ONLY the modal content */
            #historyReceiptModal, #historyReceiptModal * {
                visibility: visible;
                color: #000 !important;
            }
            
            #historyReceiptModal {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                margin: 0;
                padding: 0;
                background: white !important;
            }
            
            .modal-dialog { margin: 0 !important; max-width: 100% !important; box-shadow: none !important; border: none !important;}
            .modal-content { border: none !important; box-shadow: none !important; background-color: white !important;}
            
            /* EXPLICITLY HIDE BUTTONS */
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="bg-light p-4">

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="d-flex align-items-center">
            <a href="dashboard.php" class="btn btn-outline-dark me-3 rounded-pill px-4 shadow-sm">
                <i class="fas fa-arrow-left"></i> Back
            </a>
            <h2 class="fw-bold mb-0"><i class="fas fa-history text-danger"></i> Order History</h2>
        </div>
        
        <button id="darkModeToggle" class="btn btn-light rounded-pill border shadow-sm px-3 fw-bold" onclick="toggleDarkMode()" aria-label="Toggle Dark Mode">
            <i class="fas fa-moon" id="darkModeIcon"></i>
        </button>
    </div>

    <?php if($result->num_rows > 0): ?>
        <div class="row g-3">
        <?php while($row = $result->fetch_assoc()): 
            // Display string for the cards
            $display_items = !empty($row['plain_items']) ? $row['plain_items'] : $row['items'];
            
            // Raw detailed data for the receipt modal (handled in JS)
            $js_details = !empty($row['item_details']) ? $row['item_details'] : $row['items'];
            $js_details_safe = htmlspecialchars($js_details, ENT_QUOTES);
            
            $js_date = date("M d, Y • h:i A", strtotime($row['order_date']));
            $js_status = $row['status'];
            $js_id = $row['order_code'];
            $js_total = $row['total_price'];
        ?>
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm border-0 h-100 p-3" style="border-radius: 12px;">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <h5 class="fw-bold mb-1 text-dark">Order #<?php echo $row['order_code']; ?></h5>
                            <p class="text-muted small mb-0"><i class="far fa-clock me-1"></i> <?php echo $js_date; ?></p>
                        </div>
                        <span class="badge rounded-pill <?php echo ($row['status'] == 'Collected') ? 'bg-success' : 'bg-primary'; ?> px-3 py-2">
                            <?php echo $row['status']; ?>
                        </span>
                    </div>
                    <hr class="my-2 border-light">
                    <p class="mb-3 text-secondary small" style="min-height: 40px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                        <?php echo htmlspecialchars($display_items); ?>
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-auto pt-2">
                        <h5 class="text-dark fw-bold mb-0">₹<?php echo number_format($row['total_price'], 2); ?></h5>
                        <button class="btn btn-dark btn-sm rounded-pill px-4 fw-bold shadow-sm"
                                onclick="showReceipt('<?php echo $js_id; ?>', '<?php echo $js_date; ?>', '<?php echo $js_details_safe; ?>', '<?php echo $js_total; ?>')">
                            View Receipt
                        </button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
        </div>
    <?php else: ?>
        <div class="alert bg-white border shadow-sm text-center py-5" style="border-radius: 12px;">
            <div class="mb-3"><i class="fas fa-receipt fa-3x text-muted opacity-25"></i></div>
            <h5 class="fw-bold text-dark">No order history available</h5>
            <p class="text-muted small">Your past orders will appear here.</p>
        </div>
    <?php endif; ?>
</div>

<div class="modal fade" id="historyReceiptModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 450px;">
        <div class="modal-content professional-receipt shadow-lg">
            
            <div class="modal-body p-4 bg-white" id="printableReceipt">
                
                <div class="receipt-header">
                    <h4 class="fw-bold mb-1 text-dark">APSIT Canteen</h4>
                    <p class="text-muted small mb-0">A.P. Shah Institute of Technology</p>
                    <p class="text-muted small mb-0">Kasarvadavali, Thane West, 400615</p>
                </div>
                
                <div class="row mb-4">
                    <div class="col-6 mb-3">
                        <div class="receipt-label">Order Number</div>
                        <div class="fw-bold text-dark fs-5" id="r_id">#000</div>
                    </div>
                    <div class="col-6 mb-3 text-end">
                        <div class="receipt-label">Date & Time</div>
                        <div class="fw-bold text-dark small mt-1" id="r_date">--</div>
                    </div>
                    <div class="col-6">
                        <div class="receipt-label">Customer ID</div>
                        <div class="fw-bold text-dark small mt-1"><?php echo htmlspecialchars($moodle_id); ?></div>
                    </div>
                    <div class="col-6 text-end">
                        <div class="receipt-label">Payment Method</div>
                        <div class="fw-bold text-dark small mt-1">Online Checkout</div>
                    </div>
                </div>

                <div class="receipt-label border-bottom pb-2 mb-2">Order Summary</div>
                
                <div id="r_items" class="mb-4">
                    </div>
                
                <div class="border-top pt-3">
                    <div class="d-flex justify-content-between small mb-2 text-secondary">
                        <span>Subtotal</span>
                        <span>₹<span id="r_subtotal">0.00</span></span>
                    </div>
                    <div class="d-flex justify-content-between small mb-3 text-secondary">
                        <span>Taxes & Convenience Fees</span>
                        <span>₹0.00</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center bg-light p-3 rounded border total-pay-box">
                        <span class="fw-bold text-dark">Total Paid</span>
                        <span class="fw-bold text-dark fs-4">₹<span id="r_total">0.00</span></span>
                    </div>
                </div>

            </div>
            
            <div class="modal-footer border-top-0 bg-light p-3 no-print">
                <button class="btn btn-outline-secondary rounded-pill px-4 fw-bold w-100 w-sm-auto mb-2 mb-sm-0 bg-white" data-bs-dismiss="modal">
                    Close
                </button>
                <button class="btn btn-dark rounded-pill px-4 fw-bold w-100 w-sm-auto shadow-sm" onclick="window.print()">
                    <i class="fas fa-print me-2"></i> Print Receipt
                </button>
            </div>
            
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // --- DARK MODE LOGIC ---
    const body = document.body;
    const darkModeIcon = document.getElementById('darkModeIcon');
    
    // Check saved preference on load
    if (localStorage.getItem('darkMode') === 'enabled') {
        body.classList.add('dark-mode');
        darkModeIcon.classList.replace('fa-moon', 'fa-sun');
    }

    function toggleDarkMode() {
        body.classList.toggle('dark-mode');
        if (body.classList.contains('dark-mode')) {
            localStorage.setItem('darkMode', 'enabled');
            darkModeIcon.classList.replace('fa-moon', 'fa-sun');
        } else {
            localStorage.setItem('darkMode', 'disabled');
            darkModeIcon.classList.replace('fa-sun', 'fa-moon');
        }
    }

    // --- RECEIPT MODAL LOGIC ---
    const receiptModal = new bootstrap.Modal(document.getElementById('historyReceiptModal'));

    function showReceipt(id, date, rawData, total) {
        document.getElementById('r_id').innerText = "#" + id;
        document.getElementById('r_date').innerText = date;
        
        let formattedTotal = parseFloat(total).toFixed(2);
        document.getElementById('r_subtotal').innerText = formattedTotal;
        document.getElementById('r_total').innerText = formattedTotal;
        
        let html = '';
        
        if (rawData && rawData.includes('::')) {
            let itemsArray = rawData.split('||');
            
            itemsArray.forEach(itemStr => {
                let parts = itemStr.split('::');
                if(parts.length === 3) {
                    let name = parts[0];
                    let qty = parseInt(parts[1]);
                    let price = parseFloat(parts[2]);
                    let lineTotal = (qty * price).toFixed(2);
                    
                    html += `
                    <div class="item-line d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold text-dark">${name}</div>
                            <div class="text-muted small">₹${price.toFixed(2)} × ${qty}</div>
                        </div>
                        <div class="fw-bold text-dark">₹${lineTotal}</div>
                    </div>`;
                }
            });
        } else {
            let oldItems = rawData ? rawData.split(', ') : [];
            oldItems.forEach(item => {
                html += `
                <div class="item-line d-flex justify-content-between align-items-center">
                    <div class="fw-bold text-dark">${item}</div>
                    <div class="text-muted small">-</div>
                </div>`;
            });
        }
        
        document.getElementById('r_items').innerHTML = html;
        receiptModal.show();
    }
</script>

</body>
</html>