<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') {
    header("Location: index.php");
    exit();
}

// 1. STATS (TODAY)
$today = date('Y-m-d');
$total_orders = $conn->query("SELECT COUNT(*) FROM orders WHERE DATE(order_date) = '$today'")->fetch_row()[0];
$total_income = $conn->query("SELECT SUM(total_price) FROM orders WHERE status='Collected' AND DATE(order_date) = '$today'")->fetch_row()[0] ?? 0;
$pending_count = $conn->query("SELECT COUNT(*) FROM orders WHERE status='Preparing' AND DATE(order_date) = '$today'")->fetch_row()[0];
$ready_count = $conn->query("SELECT COUNT(*) FROM orders WHERE status='Ready' AND DATE(order_date) = '$today'")->fetch_row()[0];

// FETCH DATA
$cat_res = $conn->query("SELECT name FROM categories");
$categories = [];
while($c_row = $cat_res->fetch_assoc()) { $categories[] = $c_row['name']; }

$menu_res = $conn->query("SELECT * FROM menu");
$menu_items = [];
while($row = $menu_res->fetch_assoc()){ $menu_items[] = $row; }

$settings = $conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> 
</head>
<body style="background-color: #f4f6f9; transition: background-color 0.3s, color 0.3s; height: 100vh; overflow: hidden; display: flex; flex-direction: column;">

<nav class="navbar navbar-custom sticky-top py-3">
    <div class="container-fluid px-4">
        <a class="navbar-brand text-dark fs-4" href="#"><span style="color:#D81B60;"><i class="fas fa-utensils"></i> Campus</span> Dine Admin</a>
        
        <div class="d-flex align-items-center gap-2 gap-md-3 flex-wrap justify-content-end">
            <button class="btn btn-outline-dark rounded-pill fw-bold shadow-sm px-3 d-none d-lg-block" data-bs-toggle="modal" data-bs-target="#scheduleTimeModal">
                <i class="far fa-clock text-danger"></i> Hours
            </button>
            <button class="btn btn-outline-dark rounded-pill fw-bold shadow-sm px-3 d-none d-lg-block" data-bs-toggle="modal" data-bs-target="#editMenuModal">
                <i class="fas fa-edit text-primary"></i> Menu
            </button>
            <button class="btn btn-outline-dark rounded-pill fw-bold shadow-sm px-3 d-none d-lg-block" data-bs-toggle="modal" data-bs-target="#scheduleMenuModal">
                <i class="fas fa-calendar-alt text-success"></i> Schedule
            </button>
            
            <button id="darkModeToggle" class="btn btn-light rounded-pill border shadow-sm px-3 fw-bold" onclick="toggleDarkMode()" aria-label="Toggle Dark Mode">
                <i class="fas fa-moon" id="darkModeIcon"></i>
            </button>
            <a href="admin_history.php" class="btn btn-light rounded-pill fw-bold border shadow-sm px-3"><i class="fas fa-history text-danger me-1"></i> History</a>
            <div class="profile-icon shadow-sm border" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar">
                <img src="https://cdn-icons-png.flaticon.com/512/2206/2206368.png" alt="Admin">
            </div>
        </div>
    </div>
</nav>

<div class="container-fluid px-4 py-3 d-flex flex-column flex-grow-1" style="overflow: hidden;">

    <div class="row g-3 mb-3 flex-shrink-0">
        <div class="col-6 col-md-3"><div class="stats-card p-3 rounded-4 shadow-sm border-0 bg-white"><div class="stats-num fs-3" id="stat-orders"><?php echo $total_orders; ?></div><div class="stats-label small">Today's Orders</div></div></div>
        <div class="col-6 col-md-3"><div class="stats-card p-3 rounded-4 shadow-sm border-0 bg-white"><div class="stats-num fs-3 text-success" id="stat-income">₹<?php echo $total_income; ?></div><div class="stats-label small">Today's Income</div></div></div>
        <div class="col-6 col-md-3"><div class="stats-card p-3 rounded-4 shadow-sm border-0 bg-white"><div class="stats-num fs-3 text-warning" id="stat-pending"><?php echo $pending_count; ?></div><div class="stats-label small">Pending</div></div></div>
        <div class="col-6 col-md-3"><div class="stats-card p-3 rounded-4 shadow-sm border-0 bg-white"><div class="stats-num fs-3 text-primary" id="stat-ready"><?php echo $ready_count; ?></div><div class="stats-label small">Ready</div></div></div>
    </div>
    
    <div class="d-flex gap-2 mb-3 d-lg-none overflow-auto flex-shrink-0" style="white-space: nowrap; scrollbar-width: none;">
        <button class="btn btn-dark rounded-pill fw-bold shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#scheduleTimeModal"><i class="far fa-clock"></i> Hours</button>
        <button class="btn btn-dark rounded-pill fw-bold shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#editMenuModal"><i class="fas fa-edit"></i> Edit Menu</button>
        <button class="btn btn-dark rounded-pill fw-bold shadow-sm px-4" data-bs-toggle="modal" data-bs-target="#scheduleMenuModal"><i class="fas fa-calendar-alt"></i> Schedule</button>
    </div>

    <div class="row g-3 flex-grow-1" style="overflow: hidden;">
        
        <div class="col-md-4 d-flex flex-column h-100">
            <div class="kanban-col bg-white rounded-4 shadow-sm border d-flex flex-column h-100 overflow-hidden">
                <div class="col-header bg-warning bg-opacity-25 border-bottom d-flex justify-content-between align-items-center px-3 py-2" style="border-radius: 16px 16px 0 0;">
                    <span class="fw-bold fs-6 text-dark"><i class="fas fa-fire me-2 text-warning"></i> PENDING</span>
                    <input type="text" class="form-control form-control-sm rounded-pill shadow-sm border-0" style="max-width: 130px;" placeholder="Search ID..." onkeyup="filterOrders(this, '#listPending')">
                </div>
                <div id="listPending" class="p-2 overflow-auto flex-grow-1 bg-light"></div>
            </div>
        </div>

        <div class="col-md-4 d-flex flex-column h-100">
            <div class="kanban-col bg-white rounded-4 shadow-sm border d-flex flex-column h-100 overflow-hidden">
                <div class="col-header bg-primary bg-opacity-10 border-bottom d-flex justify-content-between align-items-center px-3 py-2" style="border-radius: 16px 16px 0 0;">
                    <span class="fw-bold fs-6 text-dark"><i class="fas fa-bell me-2 text-primary"></i> READY</span>
                    <input type="text" class="form-control form-control-sm rounded-pill shadow-sm border-0" style="max-width: 130px;" placeholder="Search ID..." onkeyup="filterOrders(this, '#listReady')">
                </div>
                <div id="listReady" class="p-2 overflow-auto flex-grow-1 bg-light"></div>
            </div>
        </div>

        <div class="col-md-4 d-flex flex-column h-100">
            <div class="kanban-col bg-white rounded-4 shadow-sm border d-flex flex-column h-100 overflow-hidden">
                <div class="col-header bg-success bg-opacity-25 border-bottom d-flex justify-content-between align-items-center px-3 py-2" style="border-radius: 16px 16px 0 0;">
                    <span class="fw-bold fs-6 text-dark"><i class="fas fa-check-double me-2 text-success"></i> COLLECTED</span>
                    <input type="text" class="form-control form-control-sm rounded-pill shadow-sm border-0" style="max-width: 130px;" placeholder="Search ID..." onkeyup="filterOrders(this, '#listCollected')">
                </div>
                <div id="listCollected" class="p-2 overflow-auto flex-grow-1 bg-light"></div>
            </div>
        </div>

    </div>
</div>

<div class="modal fade" id="scheduleTimeModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0 shadow-lg">
            <div class="modal-header border-bottom-0"><h5 class="modal-title fw-bold"><i class="far fa-clock text-danger me-2"></i> Shop Hours</h5><button type="button" class="btn-close rounded-circle" data-bs-dismiss="modal"></button></div>
            <div class="modal-body pt-0">
                <div class="row g-3">
                    <div class="col-6"><label class="small fw-bold text-muted">Open Time</label><input type="time" id="shop_open_time" class="form-control rounded-pill fw-bold text-center" value="<?php echo $settings['open_time']; ?>"></div>
                    <div class="col-6"><label class="small fw-bold text-muted">Close Time</label><input type="time" id="shop_close_time" class="form-control rounded-pill fw-bold text-center" value="<?php echo $settings['close_time']; ?>"></div>
                </div>
            </div>
            <div class="modal-footer border-top-0"><button onclick="updateShopTime()" class="btn btn-danger w-100 rounded-pill fw-bold shadow-sm" style="background-color: #D81B60; border:none;">Update Hours</button></div>
        </div>
    </div>
</div>

<div class="modal fade" id="editMenuModal" tabindex="-1">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content rounded-4 border-0 shadow-lg">
            <div class="modal-header bg-light border-bottom">
                <h5 class="modal-title fw-bold text-dark"><i class="fas fa-edit text-primary me-2"></i> Menu Management</h5>
                <button class="btn btn-dark btn-sm rounded-pill fw-bold px-3 ms-3 shadow-sm" onclick="openAddCatModal()">+ New Category</button>
                <button type="button" class="btn-close rounded-circle ms-auto" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body bg-light">
                
                <div class="d-flex align-items-center mb-3">
                    <div class="d-flex overflow-auto pb-2 flex-grow-1 gap-2" id="menuFilters" style="scrollbar-width: none;">
                         <span class="category-badge active filter-btn shadow-sm" data-cat="All" onclick="filterMenu('All', this)">All</span>
                         <?php foreach($categories as $cat): $safeCat = htmlspecialchars($cat, ENT_QUOTES); ?>
                            <div class="position-relative d-inline-block cat-wrapper shadow-sm rounded-pill" id="cat_pill_<?php echo md5($cat); ?>">
                                <span class="category-badge filter-btn m-0" data-cat="<?php echo $safeCat; ?>" onclick="filterMenu('<?php echo $safeCat; ?>', this)"><?php echo htmlspecialchars($cat); ?></span>
                                <div class="delete-cat-btn" onclick="deleteCategory('<?php echo $safeCat; ?>')"><i class="fas fa-times"></i></div>
                            </div>
                         <?php endforeach; ?>
                    </div>
                    <button class="toggle-delete-btn ms-2 shadow-sm" onclick="toggleDeleteMode(this)" title="Delete Categories"><i class="fas fa-trash-alt"></i></button>
                </div>
                
                <div class="edit-menu-grid" id="menuGrid">
                    <?php foreach($menu_items as $item): 
                        $safeName = htmlspecialchars($item['name'], ENT_QUOTES);
                        $safeCat = htmlspecialchars($item['category'], ENT_QUOTES);
                    ?>
                    <div class="edit-card item-box shadow-sm bg-white <?php echo $item['is_sold_out']?'sold-out':''; ?>" id="item_card_<?php echo $item['id']; ?>" data-cat="<?php echo $safeCat; ?>">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <span class="badge bg-light text-secondary border rounded-pill" style="font-size: 0.65rem;"><?php echo htmlspecialchars($item['category']); ?></span>
                            <div class="text-danger fw-bold item-price fs-6">₹<?php echo $item['price']; ?></div>
                        </div>
                        <div class="fw-bold item-name text-dark mb-3 text-start" style="line-height: 1.2;"><?php echo $item['name']; ?></div> 
                        <div class="edit-actions mt-auto border-top pt-2">
                            <button class="btn btn-sm btn-light border rounded-circle text-dark" title="Edit" onclick="openEditModal(<?php echo $item['id']; ?>, '<?php echo $safeName; ?>', <?php echo $item['price']; ?>, '<?php echo $safeCat; ?>')"><i class="fas fa-pen"></i></button>
                            <button class="btn btn-sm rounded-pill fw-bold px-3 shadow-sm <?php echo $item['is_sold_out']?'btn-secondary':'btn-warning text-dark'; ?> toggle-btn" onclick="toggleSoldOut(<?php echo $item['id']; ?>, this)"><?php echo $item['is_sold_out']?'Sold':'Out'; ?></button>
                            <button class="btn btn-sm btn-light border rounded-circle text-danger" title="Delete" onclick="deleteItem(<?php echo $item['id']; ?>)"><i class="fas fa-trash"></i></button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <div class="edit-card add-item-card shadow-sm" onclick="openAddItemModal()">
                        <div class="add-item-icon text-danger"><i class="fas fa-plus-circle"></i></div><div class="fw-bold">Add Item</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="scheduleMenuModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-4 border-0 shadow-lg">
            <div class="modal-header border-bottom-0"><h5 class="modal-title fw-bold text-dark"><i class="fas fa-calendar-alt text-success me-2"></i> Schedule Availability</h5><button type="button" class="btn-close rounded-circle" data-bs-dismiss="modal"></button></div>
            <div class="modal-body bg-light rounded-bottom-4 pt-0">
                <ul class="nav nav-pills nav-fill mb-4 bg-white p-1 rounded-pill shadow-sm border">
                    <li class="nav-item"><button class="nav-link active rounded-pill fw-bold" data-bs-toggle="tab" data-bs-target="#tabCategory">By Category</button></li>
                    <li class="nav-item"><button class="nav-link rounded-pill fw-bold text-dark" data-bs-toggle="tab" data-bs-target="#tabItem">By Food Item</button></li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade show active" id="tabCategory">
                        <div class="card border-0 shadow-sm rounded-4 p-3">
                            <div class="row g-3">
                                <div class="col-md-4"><label class="small fw-bold text-muted">Category</label><select id="sched_cat_name" class="form-select rounded-pill fw-bold"><?php foreach($categories as $cat) echo "<option value='".htmlspecialchars($cat, ENT_QUOTES)."'>$cat</option>"; ?></select></div>
                                <div class="col-md-3"><label class="small fw-bold text-muted">Start Time</label><input type="time" id="sched_cat_start" class="form-control rounded-pill text-center fw-bold"></div>
                                <div class="col-md-3"><label class="small fw-bold text-muted">End Time</label><input type="time" id="sched_cat_end" class="form-control rounded-pill text-center fw-bold"></div>
                                <div class="col-md-2 d-flex align-items-end"><button onclick="submitSchedCategory()" class="btn btn-dark w-100 rounded-pill fw-bold shadow-sm">Set</button></div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="tabItem">
                         <div class="edit-menu-grid">
                            <?php foreach($menu_items as $item): ?>
                            <div class="card border-0 shadow-sm rounded-3 p-3 text-start" style="border-left: 4px solid #198754;">
                                <h6 class="fw-bold mb-1 text-dark text-truncate"><?php echo htmlspecialchars($item['name']); ?></h6>
                                <small class="text-muted d-block mb-3 fw-bold"><i class="far fa-clock me-1"></i> <?php echo substr($item['avail_start'], 0, 5) . ' - ' . substr($item['avail_end'], 0, 5); ?></small>
                                <button class="btn btn-sm btn-light border rounded-pill w-100 fw-bold text-dark" onclick="openItemScheduleModal(<?php echo $item['id']; ?>, '<?php echo htmlspecialchars($item['name'], ENT_QUOTES); ?>')"><i class="far fa-edit me-1 text-success"></i> Edit Time</button>
                            </div>
                            <?php endforeach; ?>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addCategoryModal" tabindex="-1"><div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-bottom-0"><h6 class="modal-title fw-bold">New Category</h6><button type="button" class="btn-close rounded-circle" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="text" id="new_cat_name" class="form-control rounded-pill" placeholder="Category name..." required></div><div class="modal-footer border-top-0"><button type="button" onclick="submitAddCategory()" class="btn btn-dark w-100 rounded-pill fw-bold shadow-sm">Add Category</button></div></div></div></div>

<div class="modal fade" id="addItemModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-bottom-0"><h5 class="modal-title fw-bold text-dark">Add New Item</h5><button type="button" class="btn-close rounded-circle" data-bs-dismiss="modal"></button></div><div class="modal-body bg-light"><div class="card border-0 shadow-sm rounded-4 p-3"><label class="small fw-bold text-muted mb-1">Item Name</label><input type="text" id="add_name" class="form-control rounded-pill mb-3 fw-bold"><div class="row g-3"><div class="col-6"><label class="small fw-bold text-muted mb-1">Price (₹)</label><input type="number" id="add_price" class="form-control rounded-pill fw-bold"></div><div class="col-6"><label class="small fw-bold text-muted mb-1">Category</label><select id="add_cat" class="form-select rounded-pill fw-bold"><?php foreach($categories as $cat) echo "<option value='".htmlspecialchars($cat, ENT_QUOTES)."'>$cat</option>"; ?></select></div></div></div></div><div class="modal-footer border-top-0 bg-light rounded-bottom-4"><button type="button" onclick="submitAddItem()" class="btn btn-danger w-100 rounded-pill fw-bold shadow-sm" style="background-color: #D81B60; border:none;">Save Item</button></div></div></div></div>

<div class="modal fade" id="editItemModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-bottom-0"><h5 class="modal-title fw-bold text-dark">Edit Item</h5><button type="button" class="btn-close rounded-circle" data-bs-dismiss="modal"></button></div><div class="modal-body bg-light"><div class="card border-0 shadow-sm rounded-4 p-3"><input type="hidden" id="edit_id"><label class="small fw-bold text-muted mb-1">Item Name</label><input type="text" id="edit_name" class="form-control rounded-pill mb-3 fw-bold"><div class="row g-3"><div class="col-6"><label class="small fw-bold text-muted mb-1">Price (₹)</label><input type="number" id="edit_price" class="form-control rounded-pill fw-bold"></div><div class="col-6"><label class="small fw-bold text-muted mb-1">Category</label><select id="edit_cat_select" class="form-select rounded-pill fw-bold"><?php foreach($categories as $cat) echo "<option value='".htmlspecialchars($cat, ENT_QUOTES)."'>$cat</option>"; ?></select></div></div></div></div><div class="modal-footer border-top-0 bg-light rounded-bottom-4"><button type="button" onclick="submitEditItem()" class="btn btn-primary w-100 rounded-pill fw-bold shadow-sm">Update Item</button></div></div></div></div>

<div class="modal fade" id="schedItemModal" tabindex="-1"><div class="modal-dialog modal-sm modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-bottom-0"><h6 class="modal-title fw-bold text-dark text-truncate" id="sched_item_title">Set Time</h6><button type="button" class="btn-close rounded-circle" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="sched_item_id"><div class="row g-2"><div class="col-6"><label class="small fw-bold text-muted">Start</label><input type="time" id="sched_start" class="form-control rounded-pill text-center fw-bold p-1"></div><div class="col-6"><label class="small fw-bold text-muted">End</label><input type="time" id="sched_end" class="form-control rounded-pill text-center fw-bold p-1"></div></div></div><div class="modal-footer border-top-0"><button type="button" onclick="submitSchedItem()" class="btn btn-success w-100 rounded-pill fw-bold shadow-sm">Save Time</button></div></div></div></div>

<div class="offcanvas offcanvas-end" tabindex="-1" id="adminSidebar" style="border-radius: 20px 0 0 20px;">
    <div class="offcanvas-header"><h5 class="offcanvas-title fw-bold text-dark">Admin System</h5><button type="button" class="btn-close rounded-circle bg-light p-2" data-bs-dismiss="offcanvas"></button></div>
    <div class="offcanvas-body d-flex flex-column justify-content-between">
        <div>
            <div class="text-center mb-4 border-bottom pb-4">
                <div class="profile-icon mx-auto mb-2 border shadow-sm" style="width: 80px; height: 80px;"><img src="https://cdn-icons-png.flaticon.com/512/2206/2206368.png"></div>
                <h5 class="fw-bold mb-0 text-dark">Administrator</h5>
            </div>
            <label class="small text-muted fw-bold mb-2">Change Password</label>
            <input type="password" id="new_admin_pass" class="form-control rounded-pill mb-3 fw-bold" placeholder="Enter new password">
            <button class="btn btn-dark w-100 rounded-pill shadow-sm fw-bold" onclick="submitPasswordChange()"><i class="fas fa-key me-2"></i> Update Password</button>
        </div>
        <a href="index.php" class="btn btn-light border w-100 text-danger fw-bold rounded-pill shadow-sm mt-auto"><i class="fas fa-sign-out-alt me-2"></i> Secure Logout</a>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 

<script>
    // --- DARK MODE LOGIC ---
    const body = document.body;
    const darkModeIcon = document.getElementById('darkModeIcon');
    if (localStorage.getItem('darkMode') === 'enabled') {
        body.classList.add('dark-mode');
        darkModeIcon.classList.replace('fa-moon', 'fa-sun');
    }
    function toggleDarkMode() {
        body.classList.toggle('dark-mode');
        if (body.classList.contains('dark-mode')) {
            localStorage.setItem('darkMode', 'enabled');
            darkModeIcon.classList.replace('fa-moon', 'fa-sun');
        } else {
            localStorage.setItem('darkMode', 'disabled');
            darkModeIcon.classList.replace('fa-sun', 'fa-moon');
        }
    }

    let currentFilter = 'All';

    // 1. SEARCH FUNCTION
    function filterOrders(input, listId) {
        let term = input.value.toLowerCase();
        $(listId).find('.admin-order-card').each(function() {
            let text = $(this).text().toLowerCase();
            if(text.includes(term)) { $(this).show(); } else { $(this).hide(); }
        });
    }

    // 2. FILTERING (Menu)
    function filterMenu(catName, btn) {
        currentFilter = catName;
        $('.filter-btn').removeClass('active');
        $(btn).addClass('active');

        if(catName === 'All') { $('.item-box').show(); } 
        else {
            $('.item-box').hide();
            $('.item-box').filter(function() { return $(this).attr('data-cat') === catName; }).show();
        }
    }

    // 3. ADD CATEGORY
    function openAddCatModal() { new bootstrap.Modal(document.getElementById('addCategoryModal')).show(); }
    
    function submitAddCategory() {
        let name = $('#new_cat_name').val().trim();
        if(!name) return;
        
        $.post('admin_actions.php', { add_category: 1, new_cat_name: name }, function(resp) {
            if(resp.status === 'success') {
                let safeName = resp.name;
                let newBadge = `
                    <div class="position-relative d-inline-block cat-wrapper shadow-sm rounded-pill">
                        <span class="category-badge filter-btn m-0" data-cat="${safeName}" onclick="filterMenu('${safeName}', this)">${safeName}</span>
                        <div class="delete-cat-btn" onclick="deleteCategory('${safeName}')"><i class="fas fa-times"></i></div>
                    </div>`;
                $('#menuFilters').append(newBadge);
                
                let opt = `<option value="${safeName}">${safeName}</option>`;
                $('#add_cat').append(opt); $('#edit_cat_select').append(opt); $('#sched_cat_name').append(opt);
                
                bootstrap.Modal.getInstance(document.getElementById('addCategoryModal')).hide();
                $('#new_cat_name').val('');
            }
        });
    }

    // 4. ADD ITEM
    function openAddItemModal() { new bootstrap.Modal(document.getElementById('addItemModal')).show(); }

    function submitAddItem() {
        $.post('admin_actions.php', { add_item: 1, name: $('#add_name').val(), price: $('#add_price').val(), category: $('#add_cat').val() }, function(resp) {
            if(resp.status === 'success') {
                let newCard = `
                <div class="edit-card item-box shadow-sm bg-white" id="item_card_${resp.id}" data-cat="${resp.category}">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-light text-secondary border rounded-pill" style="font-size: 0.65rem;">${resp.category}</span>
                        <div class="text-danger fw-bold item-price fs-6">₹${resp.price}</div>
                    </div>
                    <div class="fw-bold item-name text-dark mb-3 text-start" style="line-height: 1.2;">${resp.name}</div> 
                    <div class="edit-actions mt-auto border-top pt-2">
                        <button class="btn btn-sm btn-light border rounded-circle text-dark" onclick="openEditModal(${resp.id}, '${resp.name}', ${resp.price}, '${resp.category}')"><i class="fas fa-pen"></i></button>
                        <button class="btn btn-sm rounded-pill fw-bold px-3 shadow-sm btn-warning text-dark toggle-btn" onclick="toggleSoldOut(${resp.id}, this)">Out</button>
                        <button class="btn btn-sm btn-light border rounded-circle text-danger" onclick="deleteItem(${resp.id})"><i class="fas fa-trash"></i></button>
                    </div>
                </div>`;
                $('.add-item-card').before(newCard);
                if(currentFilter !== 'All' && currentFilter !== resp.category) $(`#item_card_${resp.id}`).hide();
                bootstrap.Modal.getInstance(document.getElementById('addItemModal')).hide();
                $('#add_name').val(''); $('#add_price').val('');
            }
        });
    }

    // 5. EDIT ITEM
    function openEditModal(id, name, price, cat) {
        $('#edit_id').val(id); $('#edit_name').val(name); $('#edit_price').val(price); $('#edit_cat_select').val(cat);
        new bootstrap.Modal(document.getElementById('editItemModal')).show();
    }

    function submitEditItem() {
        let id = $('#edit_id').val(); let name = $('#edit_name').val(); let price = $('#edit_price').val(); let cat = $('#edit_cat_select').val();
        $.post('admin_actions.php', { update_item: 1, id: id, name: name, price: price, category: cat }, function(resp) {
            if(resp.status === 'success') {
                let card = $(`#item_card_${id}`);
                card.attr('data-cat', resp.category);
                card.find('.item-name').text(resp.name);
                card.find('.item-price').text('₹' + resp.price);
                
                let safeName = resp.name.replace(/'/g, "\\'"); let safeCat = resp.category.replace(/'/g, "\\'");
                card.find('.btn-light.text-dark').attr('onclick', `openEditModal(${id}, '${safeName}', ${resp.price}, '${safeCat}')`);

                bootstrap.Modal.getInstance(document.getElementById('editItemModal')).hide();
                if(currentFilter !== 'All' && currentFilter !== resp.category) card.hide(); else card.show();
            }
        });
    }

    // 6. UPDATE SHOP TIME
    function updateShopTime() {
        $.post('admin_actions.php', { update_shop_time: 1, open_time: $('#shop_open_time').val(), close_time: $('#shop_close_time').val() }, function(resp) {
            if(resp.status === 'success') {
                bootstrap.Modal.getInstance(document.getElementById('scheduleTimeModal')).hide();
            }
        });
    }

    // 7. SCHEDULE CATEGORY
    function submitSchedCategory() {
        $.post('admin_actions.php', { sched_cat: 1, cat_name: $('#sched_cat_name').val(), start_time: $('#sched_cat_start').val(), end_time: $('#sched_cat_end').val() }, function(resp) {
            if(resp.status === 'success') alert("Schedule updated for category!");
        });
    }

    // 8. SCHEDULE ITEM
    function openItemScheduleModal(id, name) {
        $('#sched_item_id').val(id); $('#sched_item_title').text(name);
        new bootstrap.Modal(document.getElementById('schedItemModal')).show();
    }
    
    function submitSchedItem() {
        $.post('admin_actions.php', { sched_item_single: 1, id: $('#sched_item_id').val(), start: $('#sched_start').val(), end: $('#sched_end').val() }, function(resp) {
            if(resp.status === 'success') {
                bootstrap.Modal.getInstance(document.getElementById('schedItemModal')).hide();
            }
        });
    }

    // 9. HELPERS
    function toggleSoldOut(id, btn) {
        $.post('admin_actions.php', { toggle_sold_out: 1, item_id: id }, function(resp) {
            if(resp.status === 'success') {
                let isSold = resp.is_sold_out == 1;
                $(btn).text(isSold ? 'Sold' : 'Out');
                $(btn).toggleClass('btn-secondary btn-warning text-dark');
                $(`#item_card_${id}`).toggleClass('sold-out');
            }
        });
    }

    function deleteItem(id) {
        if(confirm('Delete this item?')) {
            $.post('admin_actions.php', { delete_item: 1, item_id: id }, function(resp) {
                if(resp.status === 'success') $(`#item_card_${id}`).remove();
            });
        }
    }

    function deleteCategory(catName) {
        if(confirm(`Delete category '${catName}' and all its items?`)) {
            $.post('admin_actions.php', { delete_category: 1, cat_name: catName }, function(resp) {
                if(resp.status === 'success') {
                    $('.item-box').filter(function() { return $(this).attr('data-cat') === catName; }).remove();
                    location.reload(); 
                }
            });
        }
    }

    function toggleDeleteMode(btn) { $(btn).toggleClass('active text-white bg-danger border-danger'); $('#menuFilters').toggleClass('delete-mode'); }

    // 10. LOAD ALL 3 COLUMNS
    function loadOrders(status, containerId) {
        $.post('admin_actions.php', { fetch_orders: 1, status: status }, function(resp) {
            $(containerId).html(resp.html);
            let parentCol = $(containerId).closest('.kanban-col');
            let input = parentCol.find('input');
            if(input.val()) { filterOrders(input[0], containerId); }
        });
    }

    function updateStatus(id, newStatus) {
        $.post('admin_actions.php', { update_status: 1, order_id: id, status: newStatus }, function() {
            loadOrders('Preparing', '#listPending');
            loadOrders('Ready', '#listReady');
            loadOrders('Collected', '#listCollected');
            refreshStats();
        });
    }

    function refreshStats() {
        $.post('admin_actions.php', { fetch_stats: 1 }, function(resp) {
            let stats = (typeof resp === 'string') ? JSON.parse(resp) : resp;
            let p = parseInt(stats.pending) || 0; let r = parseInt(stats.ready) || 0; let c = parseInt(stats.collected) || 0; let i = stats.income || 0;
            $('#stat-orders').text(p + r + c); $('#stat-income').text('₹' + i); $('#stat-pending').text(p); $('#stat-ready').text(r);
        });
    }

    // MAIN LOOP (Updates all 3 columns automatically)
    setInterval(() => { 
        refreshStats();
        loadOrders('Preparing', '#listPending');
        loadOrders('Ready', '#listReady');
        loadOrders('Collected', '#listCollected');
    }, 5000);
    
    // 12. CHANGE PASSWORD (AJAX)
    function submitPasswordChange() {
        let pass = $('#new_admin_pass').val();
        if(!pass) { alert("Please enter a password"); return; }
        $.post('admin_actions.php', { change_password_admin: 1, new_password: pass }, function(resp) {
            if(resp.status === 'success') {
                alert("Password Updated Successfully!");
                $('#new_admin_pass').val('');
            } else { alert("Error: " + (resp.message || "Could not update password")); }
        });
    }
    
    // Initial Call
    loadOrders('Preparing', '#listPending');
    loadOrders('Ready', '#listReady');
    loadOrders('Collected', '#listCollected');
    refreshStats();
</script>
</body>
</html>