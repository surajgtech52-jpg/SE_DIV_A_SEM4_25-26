<?php
session_start();
include 'db_connect.php';

// FUNCTION: Generate Unique Alphanumeric ID
function generateUniqueOrderId($conn) {
    $chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $unique = false;
    $order_code = "";

    while (!$unique) {
        $length = rand(3, 7); 
        $order_code = "";
        for ($i = 0; $i < $length; $i++) {
            $order_code .= $chars[rand(0, strlen($chars) - 1)];
        }
        $check = $conn->query("SELECT id FROM orders WHERE order_code = '$order_code'");
        if ($check->num_rows == 0) $unique = true;
    }
    return $order_code;
}

// --- 1. AJAX HANDLER: LIVE TRACKER ---
if(isset($_POST['fetch_live_orders'])) {
    if(!isset($_SESSION['user_id'])) exit();
    $moodle_id = $_SESSION['user_id'];
    
    $sql_track = "SELECT o.*, 
                  (SELECT GROUP_CONCAT(CONCAT(item_name, ' (x', quantity, ')') SEPARATOR ', ') 
                   FROM order_details WHERE order_id = o.id) as item_list
                  FROM orders o 
                  WHERE o.moodle_id = '$moodle_id' 
                  AND DATE(o.order_date) = CURDATE() 
                  AND (o.status != 'Collected' OR (o.status = 'Collected' AND o.updated_at >= NOW() - INTERVAL 10 MINUTE))
                  ORDER BY o.id DESC";
    $active_orders = $conn->query($sql_track);

    if($active_orders->num_rows > 0) {
        echo '<div style="max-height: 250px; overflow-y: auto; overflow-x: hidden; padding-right: 5px;">';
        while($ord = $active_orders->fetch_assoc()) {
            $s = $ord['status'];
            $width = ($s == 'Preparing') ? "33%" : (($s == 'Ready') ? "66%" : "100%");
            $colorClass = ($s == 'Ready') ? "bg-success" : (($s == 'Collected') ? "bg-secondary" : "bg-warning");
            
            $t_prep = date("h:i A", strtotime($ord['order_date']));
            $t_ready = $ord['ready_time'] ? date("h:i A", strtotime($ord['ready_time'])) : "--:--";
            $t_coll = $ord['collected_time'] ? date("h:i A", strtotime($ord['collected_time'])) : "--:--";
            
            $display_items = !empty($ord['item_list']) ? $ord['item_list'] : $ord['items'];
            $js_items_safe = htmlspecialchars($display_items, ENT_QUOTES);
            $js_code = $ord['order_code'];
            $js_total = $ord['total_price'];
            
            echo '
            <div class="card border-0 shadow-sm mb-3 track-item" data-id="'.$ord['id'].'" data-status="'.$ord['status'].'" style="border-radius: 16px;">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <span class="text-muted small fw-bold text-uppercase" style="letter-spacing: 0.5px;">Order ID</span>
                            <h5 class="fw-bold mb-0 text-dark">#'.$js_code.'</h5>
                        </div>
                        <div class="text-end">
                            <span class="badge rounded-pill '.$colorClass.' px-3 py-2 shadow-sm">'.$s.'</span>
                        </div>
                    </div>
                    
                    <div class="position-relative mb-4 mt-2">
                        <div class="progress" style="height: 6px; border-radius: 10px; background-color: #f0f0f0;">
                            <div class="progress-bar progress-bar-striped progress-bar-animated '.$colorClass.'" role="progressbar" style="width: '.$width.';"></div>
                        </div>
                        <div class="d-flex justify-content-between mt-2 px-1">
                            <span class="text-center" style="font-size: 0.65rem; color: #666; font-weight:600;">Placed<br><span class="text-dark">'.$t_prep.'</span></span>
                            <span class="text-center" style="font-size: 0.65rem; color: #666; font-weight:600;">Ready<br><span class="text-dark">'.$t_ready.'</span></span>
                            <span class="text-center" style="font-size: 0.65rem; color: #666; font-weight:600;">Taken<br><span class="text-dark">'.$t_coll.'</span></span>
                        </div>
                    </div>
                    
                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-dark btn-sm flex-grow-1 rounded-pill fw-bold" onclick="showFullScreenId(\''.$js_code.'\')">
                            <i class="fas fa-expand me-1"></i> Show ID
                        </button>
                        <button class="btn btn-dark btn-sm flex-grow-1 rounded-pill fw-bold" onclick="showLiveSummary(\''.$js_code.'\', \''.$js_items_safe.'\', \''.$js_total.'\')">
                            <i class="fas fa-list me-1"></i> Summary
                        </button>
                    </div>
                </div>
            </div>';
        }
        echo '</div>';
    } else {
        echo '
        <div class="text-center py-4 bg-light rounded-4 border border-dashed text-muted">
            <i class="fas fa-concierge-bell fa-2x mb-2 opacity-50"></i>
            <p class="mb-0 fw-bold small">No active orders right now.</p>
        </div>';
    }
    exit(); 
}

// --- 2. SECURITY & SETUP ---
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['student', 'teacher'])) {
    header("Location: index.php");
    exit();
}

$moodle_id = $_SESSION['user_id'];
$user_role = ucfirst($_SESSION['user_role']); 
$msg = "";
date_default_timezone_set('Asia/Kolkata'); 

$settings = $conn->query("SELECT * FROM settings WHERE id=1")->fetch_assoc();
$shop_open = $settings['open_time'];
$shop_close = $settings['close_time'];

$cat_res = $conn->query("SELECT name FROM categories");
$categories = [];
while($c_row = $cat_res->fetch_assoc()) { $categories[] = $c_row['name']; }

$menu_items = $conn->query("SELECT * FROM menu");

// --- 3. HANDLE ORDER PLACEMENT ---
if(isset($_POST['place_order_final'])) {
    $cart_json = $_POST['cart_json_data']; 
    $cart_data = json_decode($cart_json, true);
    $total = $_POST['order_total_price'];
    $pickup = $_POST['order_pickup_time'];
    
    $is_valid_time = false;
    if ($shop_open < $shop_close) {
        if ($pickup >= $shop_open && $pickup <= $shop_close) $is_valid_time = true;
    } else {
        if ($pickup >= $shop_open || $pickup <= $shop_close) $is_valid_time = true;
    }

    if(!$is_valid_time) {
        $msg = "❌ Error: Please select a valid time.";
    } else if (empty($cart_data)) {
        $msg = "❌ Error: Your cart is empty!";
    } else {
        $now_ts = date('Y-m-d H:i:s');
        $new_code = generateUniqueOrderId($conn);

        $stmt = $conn->prepare("INSERT INTO orders (moodle_id, order_code, total_price, pickup_time, status, order_date) VALUES (?, ?, ?, ?, 'Preparing', ?)");
        $stmt->bind_param("ssdss", $moodle_id, $new_code, $total, $pickup, $now_ts);
        
        if($stmt->execute()) {
            $order_id = $conn->insert_id;
            
            $stmt_details = $conn->prepare("INSERT INTO order_details (order_id, item_name, quantity, price) VALUES (?, ?, ?, ?)");
            foreach($cart_data as $name => $item) {
                $qty = $item['qty'];
                $price = $item['price'];
                $stmt_details->bind_param("isid", $order_id, $name, $qty, $price);
                $stmt_details->execute();
            }

            $_SESSION['show_receipt'] = true;
            $_SESSION['last_order_id'] = $order_id;
            header("Location: dashboard.php");
            exit();
        }
    }
}

// --- 4. HANDLE PROFILE & PASSWORD ---
if(isset($_POST['update_profile'])) {
    $email = $_POST['email']; $phone = $_POST['phone']; $fullname = $_POST['full_name'];
    if(!empty($_FILES['profile_pic']['name'])){
        $target_dir = "uploads/"; $file_name = time()."_".basename($_FILES["profile_pic"]["name"]);
        move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_dir.$file_name);
        $stmt = $conn->prepare("UPDATE users SET email=?, phone=?, full_name=?, profile_pic=? WHERE moodle_id=?");
        $stmt->bind_param("sssss", $email, $phone, $fullname, $file_name, $moodle_id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET email=?, phone=?, full_name=? WHERE moodle_id=?");
        $stmt->bind_param("ssss", $email, $phone, $fullname, $moodle_id);
    }
    $stmt->execute(); header("Location: dashboard.php"); exit();
}

if(isset($_POST['change_password'])) {
    $new_pass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password=? WHERE moodle_id=?");
    $stmt->bind_param("ss", $new_pass, $moodle_id);
    if($stmt->execute()) { $msg = "Password Updated Successfully!"; }
}

// --- 5. FETCH RECEIPT DATA ---
$receipt_data = null;
$receipt_items = [];
if(isset($_SESSION['show_receipt']) && isset($_SESSION['last_order_id'])) {
    $lid = $_SESSION['last_order_id'];
    $receipt_data = $conn->query("SELECT * FROM orders WHERE id=$lid")->fetch_assoc();
    
    $items_res = $conn->query("SELECT * FROM order_details WHERE order_id=$lid");
    while($row = $items_res->fetch_assoc()) {
        $receipt_items[] = $row;
    }
}

$user = $conn->query("SELECT * FROM users WHERE moodle_id = '$moodle_id'")->fetch_assoc();
$photo_path = !empty($user['profile_pic']) && $user['profile_pic'] != 'default.png' ? "uploads/".$user['profile_pic'] : "https://cdn-icons-png.flaticon.com/512/3135/3135715.png";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard | Campus Dine</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    
    <style>
        /* DASHBOARD UI POLISH */
        body { background-color: #f8f9fa; transition: background-color 0.3s, color 0.3s; }
        
        /* Navbar */
        .navbar-custom { background: #fff; box-shadow: 0 4px 12px rgba(0,0,0,0.05); border-bottom: none; transition: background-color 0.3s; }
        .navbar-brand { font-weight: 800; letter-spacing: -0.5px; }
        
        /* Cards */
        .menu-card {
            border-radius: 20px;
            border: 1px solid rgba(0,0,0,0.05);
            transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.3s;
            background: #fff;
        }
        .menu-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.08) !important;
        }
        
        /* Schedule Box */
        .schedule-card {
            background: linear-gradient(135deg, var(--bg-card-start, #fff) 0%, var(--bg-card-end, #fcfcfc) 100%);
            border-radius: 20px;
            border: 1px solid rgba(0,0,0,0.05);
            box-shadow: 0 6px 15px rgba(0,0,0,0.04);
            padding: 1.5rem;
            transition: background 0.3s;
        }
        
        /* Category Badges */
        .category-badge {
            background: #fff;
            color: #555;
            border-radius: 30px;
            padding: 8px 20px;
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            border: 1px solid #eee;
            transition: all 0.3s ease;
            white-space: nowrap;
        }
        .category-badge.active, .category-badge:hover {
            background: #D81B60;
            color: #fff;
            border-color: #D81B60;
            box-shadow: 0 4px 10px rgba(216, 27, 96, 0.3);
        }
        
        /* Receipt Styles */
        .professional-receipt { border-radius: 8px; border: 1px solid #e0e0e0; }
        .receipt-header { text-align: center; border-bottom: 2px dashed var(--border-color, #e0e0e0); padding-bottom: 15px; margin-bottom: 15px; }
        .receipt-label { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 1px; color: #6c757d; font-weight: 700; }
        .item-line { padding: 8px 0; border-bottom: 1px solid var(--border-color, #f8f9fa); }
        .item-line:last-child { border-bottom: none; }

        
        /* ========================================= */
/* DARK MODE OVERRIDES                       */
/* ========================================= */

body.dark-mode {
    background-color: #121212 !important;
    color: #e0e0e0 !important;
}

body.dark-mode .navbar-custom {
    background-color: #1e1e1e !important;
    border-bottom: 1px solid #333 !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.6) !important;
}

body.dark-mode .navbar-brand.text-dark {
    color: #e0e0e0 !important;
}

/* Base element overrides */
body.dark-mode .bg-white,
body.dark-mode .bg-light,
body.dark-mode .card,
body.dark-mode .menu-card,
body.dark-mode .tracker-card,
body.dark-mode .modal-content,
body.dark-mode .offcanvas {
    background-color: #1e1e1e !important;
    border-color: #333 !important;
    color: #e0e0e0 !important;
}

/* FIX 1: Schedule Card White Box Issue */
/* Overrides the light mode background gradient */
body.dark-mode .schedule-card {
    background: linear-gradient(135deg, #2a2a2a 0%, #1e1e1e 100%) !important;
    border-color: #333 !important;
}

/* FIX 2: Inner Time Input Container */
body.dark-mode .time-input-container {
    background-color: #121212 !important; /* Deep dark inset look */
    border-color: #444 !important;
}

/* FIX 3: Form Select Dropdown Arrow (Chevron) Visibility */
/* Replaces Bootstrap's default black SVG arrow with a light gray one */
body.dark-mode .form-select {
    background-color: transparent !important;
    color: #e0e0e0 !important;
    border-color: #444 !important;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%23e0e0e0' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e") !important;
}
body.dark-mode .form-select option {
    background-color: #2c2c2c;
    color: #e0e0e0;
}

/* Text color overrides */
body.dark-mode .text-dark {
    color: #ffffff !important; /* Crisp white for headings */
}
body.dark-mode .text-muted {
    color: #9e9e9e !important;
}

/* Adjusting Shadows for Dark Mode (Deepens them) */
body.dark-mode .shadow-sm,
body.dark-mode .shadow,
body.dark-mode .shadow-lg {
    box-shadow: 0 4px 15px rgba(0,0,0,0.6) !important;
}

/* Borders */
body.dark-mode .border,
body.dark-mode .border-bottom,
body.dark-mode .border-top,
body.dark-mode .border-start {
    border-color: #333 !important;
}
body.dark-mode .border-dashed {
    border-color: #444 !important;
}

/* Badges & Buttons */
body.dark-mode .category-badge {
    background-color: #2c2c2c !important;
    color: #e0e0e0 !important;
    border-color: #444 !important;
}
body.dark-mode .category-badge.active,
body.dark-mode .category-badge:hover {
    background-color: #D81B60 !important;
    color: white !important;
    border-color: #D81B60 !important;
}

/* Exempt the floating cart badge so it stays easily readable */
body.dark-mode .badge.bg-white {
    background-color: #ffffff !important;
    color: #D81B60 !important;
}

body.dark-mode .btn-light {
    background-color: #2c2c2c !important;
    color: #e0e0e0 !important;
    border-color: #444 !important;
}
body.dark-mode .btn-light:hover {
    background-color: #3a3a3a !important;
}
body.dark-mode .btn-outline-dark {
    color: #e0e0e0 !important;
    border-color: #e0e0e0 !important;
}
body.dark-mode .btn-outline-dark:hover {
    background-color: #e0e0e0 !important;
    color: #1e1e1e !important;
}

/* Cart & Modals */
body.dark-mode .list-group-item {
    background-color: transparent !important;
    border-color: #333 !important;
}
body.dark-mode .qty-controls {
    background-color: #2c2c2c !important;
    border-color: #444 !important;
}
body.dark-mode .empty-cart-box,
body.dark-mode .total-pay-box {
    background-color: #121212 !important;
    border-color: #333 !important;
}

/* Track Items */
body.dark-mode .track-item {
    background-color: #262626 !important;
    border-color: #333 !important;
}
body.dark-mode .progress {
    background-color: #444 !important;
}

/* Offcanvas close button (make it visible on dark bg) */
body.dark-mode .btn-close {
    background-color: #444 !important;
    filter: invert(1) grayscale(100%) brightness(200%);
    opacity: 0.8;
}
/* ========================================= */
/* FIX: PROFILE INPUTS IN DARK MODE          */
/* ========================================= */

/* 1. Make all input fields dark with white text */
body.dark-mode .form-control,
body.dark-mode .form-select,
body.dark-mode .input-group-text {
    background-color: #2c2c2c !important;
    color: #ffffff !important;
    border-color: #444 !important;
}

/* 2. Style the inputs when you click on them (Focus state) */
body.dark-mode .form-control:focus,
body.dark-mode .form-select:focus {
    background-color: #333 !important;
    color: #ffffff !important;
    border-color: #D81B60 !important;
    box-shadow: 0 0 0 0.25rem rgba(216, 27, 96, 0.25) !important;
}

/* 3. Style the "Choose File" button specifically */
body.dark-mode .form-control::file-selector-button {
    background-color: #444 !important;
    color: #ffffff !important;
    border: none !important;
    border-right: 1px solid #555 !important;
    margin-right: 10px;
}

/* 4. Fix Bootstrap's "text-dark" class overriding the white text */
body.dark-mode .text-dark {
    color: #ffffff !important;
}

/* 5. Ensure the sidebar background is consistently dark */
body.dark-mode .offcanvas,
body.dark-mode .offcanvas-header,
body.dark-mode .offcanvas-body {
    background-color: #1e1e1e !important;
    color: #e0e0e0 !important;
}

/* 6. Fix the "Logout" button so it pops in dark mode */
body.dark-mode .offcanvas .btn-light.text-danger {
    background-color: #2c2c2c !important;
    color: #ff4d4d !important; /* Bright red for visibility */
    border-color: #444 !important;
}
body.dark-mode .offcanvas .btn-light.text-danger:hover {
    background-color: #3a3a3a !important;
}
/* ========================================= */
/* FIX: CLOSE BUTTONS (X) IN DARK MODE       */
/* ========================================= */

body.dark-mode .btn-close {
    /* Remove any weird inversion filters */
    filter: none !important;
    
    /* Set a deep dark circular background */
    background-color: #333 !important;
    
    /* Inject a pure white 'X' SVG icon */
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%23ffffff'%3e%3cpath d='M.293.293a1 1 0 0 1 1.414 0L8 6.586 14.293.293a1 1 0 1 1 1.414 1.414L9.414 8l6.293 6.293a1 1 0 0 1-1.414 1.414L8 9.414l-6.293 6.293a1 1 0 0 1-1.414-1.414L6.586 8 .293 1.707a1 1 0 0 1 0-1.414z'/%3e%3c/svg%3e") !important;
    
    background-size: 12px !important;
    background-repeat: no-repeat !important;
    background-position: center !important;
    opacity: 0.8 !important;
    border: 1px solid #444 !important;
}

body.dark-mode .btn-close:hover {
    background-color: #444 !important;
    opacity: 1 !important;
    box-shadow: 0 0 8px rgba(255, 255, 255, 0.1) !important;
}
/* Ensure receipt modal isn't affected by dark mode for printing purposes */
@media print {
    body.dark-mode #receiptModal, 
    body.dark-mode #receiptModal *,
    body.dark-mode #printableReceipt {
        background-color: white !important;
        color: black !important;
        border-color: #ccc !important;
    }
}
        @media print {
            @page { size: auto; margin: 10mm; }
            body, html { background-color: white !important; height: auto; }
            body * { visibility: hidden; }
            #receiptModal, #receiptModal * { visibility: visible; color: #000 !important; }
            #receiptModal { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 0; background: white !important; }
            .modal-dialog { margin: 0 !important; max-width: 100% !important; box-shadow: none !important; border: none !important;}
            .modal-content { border: none !important; box-shadow: none !important;}
            .no-print { display: none !important; }
            .modal-backdrop { display: none !important; }
            /* FIX 4: Form Inputs & Profile Sidebar Visibility */
body.dark-mode .form-control {
    background-color: #2c2c2c !important;
    color: #ffffff !important; /* Forces text to be visible */
    border-color: #444 !important;
}

/* Style the input when the user clicks on it */
body.dark-mode .form-control:focus {
    background-color: #333 !important;
    color: #ffffff !important;
    border-color: #D81B60 !important;
    box-shadow: 0 0 0 0.25rem rgba(216, 27, 96, 0.25) !important;
}

/* Style the "Choose File" button for the profile photo in Dark Mode */
body.dark-mode .form-control::file-selector-button {
    background-color: #444 !important;
    color: #ffffff !important;
    border: none !important;
    border-right: 1px solid #555 !important;
    margin-right: 10px;
}

/* Ensure the Profile Sidebar background stays deep dark */
body.dark-mode .offcanvas,
body.dark-mode .offcanvas-header,
body.dark-mode .offcanvas-body {
    background-color: #1e1e1e !important;
    color: #e0e0e0 !important;
}
        }
    </style>
</head>
<body>

<div class="toast-container position-fixed bottom-0 end-0 p-3" style="z-index: 10000;">
  <div id="cartToast" class="toast align-items-center text-bg-dark border-0 shadow-lg" style="border-radius:12px;" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="d-flex">
      <div class="toast-body fw-bold" id="toastMsg">Item added to cart!</div>
      <button type="button" class="btn-close btn-close-white me-3 m-auto" data-bs-dismiss="toast"></button>
    </div>
  </div>
</div>

<nav class="navbar navbar-custom sticky-top py-3">
    <div class="container px-4">
        <a class="navbar-brand text-dark fs-4" href="#"><span style="color:#D81B60;"><i class="fas fa-utensils"></i> Campus</span> Dine</a>
        <div class="d-flex align-items-center gap-2 gap-md-3">
            <button id="darkModeToggle" class="btn btn-light rounded-pill border shadow-sm px-3 fw-bold" onclick="toggleDarkMode()" aria-label="Toggle Dark Mode">
                <i class="fas fa-moon" id="darkModeIcon"></i>
            </button>
            <a href="order_history.php" class="btn btn-light rounded-pill fw-bold small shadow-sm border px-3"><i class="fas fa-history text-danger me-1"></i> History</a>
            <div class="profile-icon shadow-sm border" data-bs-toggle="offcanvas" data-bs-target="#profileSidebar"><img src="<?php echo $photo_path; ?>"></div>
        </div>
    </div>
</nav>

<div class="container py-4">
    <?php if($msg) echo "<div class='alert alert-info shadow-sm rounded-pill fw-bold text-center border-0'>$msg</div>"; ?>

    <div class="row g-4 mb-4">
        <div class="col-md-5 col-lg-4">
            <div class="schedule-card h-100">
                <div class="d-flex align-items-center mb-3">
                    <div class="bg-danger bg-opacity-10 text-danger p-2 rounded-circle me-3">
                        <i class="fas fa-clock fs-5"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold mb-0 text-dark">Pickup Time</h5>
                        <small class="text-muted">Today: <?php echo date("h:i A", strtotime($shop_open)); ?> - <?php echo date("h:i A", strtotime($shop_close)); ?></small>
                    </div>
                </div>
                
                <div class="d-flex gap-2 bg-white p-2 rounded-pill shadow-sm border time-input-container">
                    <select id="hourSelect" class="form-select border-0 bg-transparent text-center fw-bold text-dark" style="cursor:pointer;" onchange="combineTime()">
                        <option value="">Hr</option>
                    </select>
                    <div class="text-muted fw-bold align-self-center">:</div>
                    <select id="minSelect" class="form-select border-0 bg-transparent text-center fw-bold text-dark" style="cursor:pointer;" onchange="combineTime()">
                        <option value="">Min</option>
                        <option value="00">00</option><option value="15">15</option><option value="30">30</option><option value="45">45</option>
                    </select>
                </div>
                
                <input type="hidden" id="scheduleTime" name="order_pickup_time">
                <input type="hidden" id="hidden_time_card">
            </div>
        </div>

        <div class="col-md-7 col-lg-8">
            <div class="bg-white rounded-4 shadow-sm border p-3 h-100" style="border-radius: 20px !important;">
                <h6 class="fw-bold mb-3 px-2 text-uppercase text-muted small" style="letter-spacing:1px;"><i class="fas fa-satellite-dish text-success me-1"></i> Live Orders</h6>
                <div id="liveTrackerBox">
                    <div class="text-center py-4 text-muted"><i class="fas fa-spinner fa-spin fa-2x mb-2"></i><p class="mb-0 small fw-bold">Loading tracker...</p></div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex overflow-auto mb-4 pb-2 gap-2 px-1" id="filterContainer" style="scrollbar-width: none;">
        <span class="category-badge active shadow-sm" onclick="filterMenu('All', this)">All Items</span>
        <?php foreach($categories as $cat): ?>
            <span class="category-badge shadow-sm" onclick="filterMenu('<?php echo htmlspecialchars($cat, ENT_QUOTES); ?>', this)"><?php echo htmlspecialchars($cat); ?></span>
        <?php endforeach; ?>
    </div>

    <div class="row g-3">
        <?php 
        $current_time = date('H:i:s');
        while($item = $menu_items->fetch_assoc()): 
            $is_available = false;
            $status_text = "Closed";

            if ($shop_open < $shop_close) {
                if ($current_time >= $shop_open && $current_time <= $shop_close) $is_available = true;
                else $status_text = "Shop Closed";
            } else {
                if ($current_time >= $shop_open || $current_time <= $shop_close) $is_available = true;
                else $status_text = "Shop Closed";
            }

            if ($is_available) {
                if ($item['avail_start'] < $item['avail_end']) {
                    if (!($current_time >= $item['avail_start'] && $current_time <= $item['avail_end'])) {
                        $is_available = false; 
                        $status_text = "Closed (" . substr($item['avail_start'],0,5) . ")";
                    }
                } else {
                    if (!($current_time >= $item['avail_start'] || $current_time <= $item['avail_end'])) {
                        $is_available = false;
                        $status_text = "Closed";
                    }
                }
            }

            if($item['is_sold_out']) {
                $is_available = false; 
                $status_text = "Sold Out";
            }
            
            $safeName = htmlspecialchars($item['name'], ENT_QUOTES);
        ?>
        <div class="col-6 col-md-4 col-lg-3 menu-item-col" data-category="<?php echo htmlspecialchars($item['category'], ENT_QUOTES); ?>">
            <div class="card menu-card h-100 p-3 shadow-sm <?php echo !$is_available ? 'bg-light border opacity-75' : ''; ?>">
                <div class="d-flex justify-content-between mb-2">
                    <span class="badge bg-light text-secondary border rounded-pill fw-bold" style="font-size: 0.7rem;"><?php echo htmlspecialchars($item['category']); ?></span>
                    <span class="fw-bold text-dark fs-5">₹<?php echo $item['price']; ?></span>
                </div>
                <h6 class="fw-bold mb-2 mt-1 text-dark" style="line-height: 1.3; min-height: 2.6rem;">
                    <?php echo htmlspecialchars($item['name']); ?>
                </h6>
                <?php if($is_available): ?>
                    <button class="btn btn-light border btn-sm w-100 mt-auto add-btn disabled-btn rounded-pill fw-bold text-dark hover-shadow" 
                            onclick="addToCart('<?php echo $safeName; ?>', <?php echo $item['price']; ?>)">Add +</button>
                <?php else: ?>
                    <button class="btn btn-sm btn-secondary w-100 mt-auto rounded-pill fw-bold border-0" disabled><?php echo $status_text; ?></button>
                <?php endif; ?>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<div class="floating-cart shadow-lg border border-white" id="floatBtn" onclick="openCartModal()" style="border-radius: 30px; background-color: #D81B60;">
    <i class="fas fa-shopping-basket me-2"></i> 
    <span class="badge bg-white text-danger rounded-circle p-2 px-2 shadow-sm me-2" id="cartCount">0</span> 
    <span class="fw-bold fs-6 border-start border-light ps-2 border-opacity-50">₹<span id="cartTotalBtn">0</span></span>
</div>

<div class="modal fade" id="cartModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
            <div class="modal-header border-bottom-0 pb-0">
                <h5 class="modal-title fw-bold text-dark">Your Cart</h5>
                <button type="button" class="btn-close bg-light rounded-circle p-2" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <ul class="list-group mb-3" id="cartList" style="max-height: 400px; overflow-y: auto;"></ul>
                <div class="d-flex justify-content-between align-items-center bg-light p-3 rounded-4 border mt-3 total-pay-box">
                    <span class="fw-bold text-muted text-uppercase small">Total to Pay:</span>
                    <span class="fw-bold fs-4 text-dark">₹<span id="cartTotalModal">0</span></span>
                </div>
            </div>
            <div class="modal-footer border-0 pt-0">
                <form method="POST" class="w-100">
                    <input type="hidden" name="cart_json_data" id="hidden_cart_json">
                    <input type="hidden" name="order_total_price" id="hidden_total">
                    <input type="hidden" name="order_pickup_time" id="hidden_time">
                    <button type="submit" name="place_order_final" class="btn btn-danger w-100 fw-bold shadow-sm p-3 rounded-pill fs-5" style="background-color: #D81B60; border: none;">Proceed to Pay</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="liveSummaryModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
            <div class="modal-header border-bottom-0 pb-0">
                <h6 class="modal-title fw-bold text-uppercase text-muted small"><i class="fas fa-list me-1"></i> Order Summary</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body pt-2">
                <h4 class="fw-bold text-dark mb-3" id="ls_code">#000</h4>
                <div class="ps-3 mb-3 border-start border-danger border-3" id="ls_items" style="font-size: 0.9rem; font-weight: 500;">
                    </div>
                <hr class="border-dashed my-2">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="fw-bold text-muted small text-uppercase">Total</span>
                    <span class="fw-bold fs-5 text-dark">₹<span id="ls_total">0</span></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="timeAlertModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 20px;">
            <div class="modal-body text-center p-4">
                <div class="mb-3">
                    <div class="d-inline-flex align-items-center justify-content-center rounded-circle bg-warning bg-opacity-10 text-warning" style="width: 60px; height: 60px;">
                        <i class="fas fa-clock fs-3"></i>
                    </div>
                </div>
                <h5 class="fw-bold mb-2 text-dark" id="timeAlertTitle">Alert</h5>
                <p class="text-muted small mb-4" id="timeAlertMessage">Message here</p>
                <div class="d-grid gap-2">
                    <button type="button" class="btn btn-danger fw-bold rounded-pill shadow-sm" id="timeAlertSetBtn" style="display: none; background-color: #D81B60; border:none;">Set Time</button>
                    <button type="button" class="btn btn-light fw-bold rounded-pill text-dark" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="offcanvas offcanvas-end" tabindex="-1" id="profileSidebar" style="border-radius: 20px 0 0 20px;">
    <div class="offcanvas-header"><h5 class="offcanvas-title fw-bold text-dark">My Profile</h5><button type="button" class="btn-close bg-light rounded-circle p-2" data-bs-dismiss="offcanvas"></button></div>
    <div class="offcanvas-body">
        <div class="text-center mb-4">
            <div class="profile-icon mx-auto mb-2 border shadow-sm" style="width: 100px; height: 100px;"><img src="<?php echo $photo_path; ?>" style="width:100%; height:100%; object-fit:cover; border-radius:50%;"></div>
            <h4 class="fw-bold mb-0 text-dark"><?php echo htmlspecialchars($user['full_name']); ?></h4>
            <p class="text-muted small fw-bold"><?php echo $user['moodle_id']; ?></p>
        </div>
        <form method="POST" enctype="multipart/form-data" onsubmit="return validateProfile()">
            <div class="mb-3"><label class="small text-muted fw-bold">Change Photo</label><input type="file" name="profile_pic" class="form-control rounded-pill"></div>
            <div class="mb-3"><label class="small text-muted fw-bold">Full Name</label><input type="text" id="p_name" name="full_name" class="form-control rounded-pill fw-bold text-dark" value="<?php echo htmlspecialchars($user['full_name']); ?>"></div>
            <div class="mb-3"><label class="small text-muted fw-bold">Email</label><input type="email" id="p_email" name="email" class="form-control rounded-pill fw-bold text-dark" value="<?php echo htmlspecialchars($user['email']); ?>"></div>
            <div class="mb-3"><label class="small text-muted fw-bold">Phone</label><input type="text" id="p_phone" name="phone" class="form-control rounded-pill fw-bold text-dark" value="<?php echo htmlspecialchars($user['phone']); ?>"></div>
            <button type="submit" name="update_profile" class="btn btn-dark w-100 mb-4 rounded-pill shadow-sm fw-bold">Save Changes</button>
        </form>
        <hr class="border-dashed my-4">
        <form method="POST">
             <label class="small text-muted fw-bold">New Password</label>
             <div class="input-group mb-3"><input type="password" name="new_password" class="form-control rounded-start-pill" placeholder="Enter new password" required><button class="btn btn-danger rounded-end-pill fw-bold" style="background-color: #D81B60; border:none;" type="submit" name="change_password">Update</button></div>
        </form>
        <a href="index.php" class="btn btn-light border w-100 text-danger fw-bold rounded-pill mt-2">Logout</a>
    </div>
</div>

<?php if (isset($receipt_data)): ?>
<div class="modal fade show" id="receiptModal" tabindex="-1" style="display:block; background:rgba(0,0,0,0.6);">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 450px;">
        <div class="modal-content professional-receipt shadow-lg bg-white">
            
            <div class="modal-body p-4" id="printableReceipt">
                
                <div class="text-center mb-3">
                    <i class="fas fa-check-circle text-success" style="font-size: 3.5rem;"></i>
                    <h5 class="fw-bold text-dark mt-2 mb-0">Payment Successful!</h5>
                </div>

                <div class="receipt-header">
                    <h4 class="fw-bold mb-1 text-dark">APSIT Canteen</h4>
                    <p class="text-muted small mb-0">A.P. Shah Institute of Technology</p>
                    <p class="text-muted small mb-0">Kasarvadavali, Thane West, 400615</p>
                </div>
                
                <div class="row mb-4">
                    <div class="col-6 mb-3">
                        <div class="receipt-label">Order Number</div>
                        <div class="fw-bold text-dark fs-5">#<?php echo $receipt_data['order_code']; ?></div>
                    </div>
                    <div class="col-6 mb-3 text-end">
                        <div class="receipt-label">Date & Time</div>
                        <div class="fw-bold text-dark small mt-1"><?php echo date("M d, Y • h:i A", strtotime($receipt_data['order_date'])); ?></div>
                    </div>
                    <div class="col-6">
                        <div class="receipt-label">Customer ID</div>
                        <div class="fw-bold text-dark small mt-1"><?php echo htmlspecialchars($moodle_id); ?></div>
                    </div>
                    <div class="col-6 text-end">
                        <div class="receipt-label">Payment Method</div>
                        <div class="fw-bold text-dark small mt-1">Online Checkout</div>
                    </div>
                </div>

                <div class="receipt-label border-bottom pb-2 mb-2">Order Summary</div>
                
                <div class="mb-4">
                    <?php foreach($receipt_items as $r_item): ?>
                    <div class="item-line d-flex justify-content-between align-items-center">
                        <div>
                            <div class="fw-bold text-dark"><?php echo htmlspecialchars($r_item['item_name']); ?></div>
                            <div class="text-muted small">₹<?php echo number_format($r_item['price'], 2); ?> × <?php echo $r_item['quantity']; ?></div>
                        </div>
                        <div class="fw-bold text-dark">₹<?php echo number_format($r_item['price'] * $r_item['quantity'], 2); ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="border-top pt-3">
                    <div class="d-flex justify-content-between small mb-2 text-secondary">
                        <span>Subtotal</span>
                        <span>₹<?php echo number_format($receipt_data['total_price'], 2); ?></span>
                    </div>
                    <div class="d-flex justify-content-between small mb-3 text-secondary">
                        <span>Taxes & Convenience Fees</span>
                        <span>₹0.00</span>
                    </div>
                    <div class="d-flex justify-content-between align-items-center bg-light p-3 rounded border total-pay-box">
                        <span class="fw-bold text-dark">Total Paid</span>
                        <span class="fw-bold text-dark fs-4">₹<?php echo number_format($receipt_data['total_price'], 2); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer border-top-0 bg-light p-3 no-print">
                <a href="dashboard.php" class="btn btn-outline-secondary rounded-pill px-4 fw-bold w-100 w-sm-auto mb-2 mb-sm-0 bg-white text-dark border">
                    Close
                </a>
                <button class="btn btn-dark rounded-pill px-4 fw-bold w-100 w-sm-auto shadow-sm" onclick="window.print()">
                    <i class="fas fa-print me-2"></i> Print Receipt
                </button>
            </div>
            
        </div>
    </div>
</div>
<?php unset($_SESSION['show_receipt']); ?>
<?php endif; ?>

<style>
    #fullScreenOverlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: #198754; z-index: 10000; flex-direction: column; justify-content: center; align-items: center; text-align: center; transition: all 0.3s ease; }
    #overlayOrderId { font-size: 13vw; line-height: 1; word-break: keep-all; text-shadow: 2px 2px 10px rgba(0,0,0,0.2);}
    #fullScreenOverlay.rotate-screen { width: 100vh; height: 100vw; transform: rotate(90deg); transform-origin: center; position: fixed; left: 50%; top: 50%; margin-left: -50vh; margin-top: -50vw; }
    #fullScreenOverlay.rotate-screen #overlayOrderId { font-size: 13vh; }
    .border-dashed { border-style: dashed !important; border-color: #ccc !important; }
</style>

<div id="fullScreenOverlay">
    <button onclick="closeFullScreen()" class="btn btn-outline-light border-0" style="position:absolute; top:20px; right:20px; font-size:40px; line-height:1; z-index:10001;">&times;</button>
    <div>
        <h2 class="text-white text-uppercase mb-2 fw-bold" style="letter-spacing: 3px; font-size: 3vmin; opacity: 0.9;">Your Order Number</h2>
        <h1 class="text-white fw-bold" id="overlayOrderId">#00</h1>
    </div>
    <button onclick="toggleLandscape()" class="btn btn-light fw-bold rounded-pill shadow" style="position:absolute; bottom:40px; padding: 10px 30px; font-size: 1rem;">
        <i class="fas fa-sync-alt me-2"></i> Rotate View
    </button>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // --- DARK MODE LOGIC ---
    const body = document.body;
    const darkModeIcon = document.getElementById('darkModeIcon');
    
    // Check saved preference on load
    if (localStorage.getItem('darkMode') === 'enabled') {
        body.classList.add('dark-mode');
        darkModeIcon.classList.replace('fa-moon', 'fa-sun');
    }

    function toggleDarkMode() {
        body.classList.toggle('dark-mode');
        if (body.classList.contains('dark-mode')) {
            localStorage.setItem('darkMode', 'enabled');
            darkModeIcon.classList.replace('fa-moon', 'fa-sun');
        } else {
            localStorage.setItem('darkMode', 'disabled');
            darkModeIcon.classList.replace('fa-sun', 'fa-moon');
        }
    }

    let cart = {}; 
    let isTimeSelected = false;

    // --- NOTIFICATION SYSTEM ---
    let notifiedOrders = []; 
    const notificationSound = new Audio('https://actions.google.com/sounds/v1/alarms/beep_short.ogg'); 

    if ("Notification" in window) {
        if (Notification.permission !== "granted") {
            Notification.requestPermission();
        }
    }

    function checkNotifications() {
        const orders = document.querySelectorAll('.track-item');
        orders.forEach(order => {
            const id = order.getAttribute('data-id');
            const status = order.getAttribute('data-status');
            if (status === 'Ready' && !notifiedOrders.includes(id)) {
                notificationSound.play().catch(error => console.log("Audio play blocked"));
                if (Notification.permission === "granted") {
                    new Notification("Order Ready! 🍔", {
                        body: `Order #${id} is ready for pickup!`,
                        icon: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png" 
                    });
                }
                notifiedOrders.push(id);
            }
        });
    }

    const shopOpenStr = "<?php echo $shop_open; ?>"; 
    const shopCloseStr = "<?php echo $shop_close; ?>"; 
    const shopOpenHour = parseInt(shopOpenStr.split(':')[0]);
    const shopCloseHour = parseInt(shopCloseStr.split(':')[0]);
    const currentHour = <?php echo (int)date('H'); ?>;

    function initTimeDropdowns() {
        const hSelect = document.getElementById('hourSelect');
        let html = '<option value="">Hr</option>';
        let hoursList = [];

        if (shopOpenHour < shopCloseHour) {
            for (let h = shopOpenHour; h <= shopCloseHour; h++) hoursList.push(h);
        } else {
            for (let h = shopOpenHour; h <= 23; h++) hoursList.push(h);
            for (let h = 0; h <= shopCloseHour; h++) hoursList.push(h);
        }
        hoursList.forEach(h => {
            let isValid = false;
            if (shopOpenHour < shopCloseHour) { if (h >= currentHour) isValid = true; } 
            else { if (currentHour >= shopOpenHour) { if (h >= currentHour || h <= shopCloseHour) isValid = true; } else { if (h >= currentHour && h <= shopCloseHour) isValid = true; } }

            if (isValid) {
                let val = h < 10 ? '0' + h : h;
                let disp = h;
                let ampm = 'AM';
                if(h >= 12) { ampm = 'PM'; if(h > 12) disp = h - 12; }
                if(h === 0) { disp = 12; ampm = 'AM'; }
                html += `<option value="${val}">${disp} ${ampm}</option>`;
            }
        });

        if (html === '<option value="">Hr</option>') html = '<option value="">Closed</option>';
        hSelect.innerHTML = html;
    }

    let alertModalInstance = null;

    function showTimeModal(title, message, suggH, suggM, displayTime) {
        if (!alertModalInstance) { alertModalInstance = new bootstrap.Modal(document.getElementById('timeAlertModal')); }
        document.getElementById('timeAlertTitle').innerHTML = title;
        document.getElementById('timeAlertMessage').innerHTML = message;
        
        const setBtn = document.getElementById('timeAlertSetBtn');
        if (suggH !== null && suggM !== null) {
            setBtn.style.display = 'block';
            setBtn.innerHTML = `Set to ${displayTime}`;
            setBtn.onclick = function() {
                document.getElementById('hourSelect').value = suggH;
                document.getElementById('minSelect').value = suggM;
                alertModalInstance.hide();
                combineTime();
            };
        } else {
            setBtn.style.display = 'none';
        }
        alertModalInstance.show();
    }

    function combineTime() {
        const hVal = document.getElementById('hourSelect').value;
        const mVal = document.getElementById('minSelect').value;
        const hiddenInput = document.getElementById('scheduleTime');
        const modalInput = document.getElementById('hidden_time');

        if (hVal !== "" && mVal !== "") {
            const selectedTimeStr = `${hVal}:${mVal}:00`;
            if (!validateRange(selectedTimeStr)) {
                showTimeModal("Shop is Closed", `The canteen does not operate at ${hVal}:${mVal}.<br>Operating Hours: <strong>${shopOpenStr.substring(0,5)} to ${shopCloseStr.substring(0,5)}</strong>`, null, null, null);
                resetSelection(); return;
            }
            if (!validateBuffer(parseInt(hVal), parseInt(mVal))) return; 

            const combined = `${hVal}:${mVal}`;
            hiddenInput.value = combined;
            if(modalInput) modalInput.value = combined;
            enableOrdering(); 
        } else {
            hiddenInput.value = ""; isTimeSelected = false;
        }
    }

    function validateRange(selTime) {
        if (shopOpenStr < shopCloseStr) { return (selTime >= shopOpenStr && selTime <= shopCloseStr); } 
        else { return (selTime >= shopOpenStr || selTime <= shopCloseStr); }
    }

    function validateBuffer(selH, selM) {
        const now = new Date(); const selected = new Date();
        selected.setHours(selH); selected.setMinutes(selM); selected.setSeconds(0);

        if (selH < now.getHours() && selH <= shopCloseHour) selected.setDate(selected.getDate() + 1);

        const minTime = new Date(now.getTime() + 30 * 60000);

        if (selected < minTime) {
            let suggestH = minTime.getHours(); let suggestM = minTime.getMinutes();
            const remainder = suggestM % 15;
            if (remainder !== 0) suggestM += (15 - remainder);
            if (suggestM === 60) { suggestM = 0; suggestH += 1; }
            if (suggestH === 24) suggestH = 0;

            let suggAmpm = suggestH >= 12 ? 'PM' : 'AM';
            let suggDispH = suggestH > 12 ? suggestH - 12 : (suggestH === 0 ? 12 : suggestH);
            let suggDispM = suggestM < 10 ? '0' + suggestM : suggestM;
            let optionH = suggestH < 10 ? '0' + suggestH : suggestH;
            let optionM = suggestM < 10 ? '0' + suggestM : suggestM;

            showTimeModal("Too Soon!", `Please order at least 30 mins in advance.<br>Earliest valid time: <strong>${suggDispH}:${suggDispM} ${suggAmpm}</strong>`, optionH, optionM, `${suggDispH}:${suggDispM} ${suggAmpm}`);
            resetSelection(); return false;
        }
        return true;
    }

    function resetSelection() {
        document.getElementById('minSelect').value = ""; document.getElementById('scheduleTime').value = ""; isTimeSelected = false;
        document.querySelectorAll('.add-btn').forEach(b => { 
            b.classList.remove('btn-danger', 'text-white'); 
            b.classList.add('btn-light', 'disabled-btn'); 
        });
    }

    function enableOrdering() {
        isTimeSelected = true; 
        document.querySelectorAll('.add-btn').forEach(b => { 
            b.classList.remove('btn-light','disabled-btn'); 
            b.classList.add('btn-danger', 'text-white');
            b.style.backgroundColor = '#D81B60';
        });
    }

    setInterval(function() {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", "dashboard.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("liveTrackerBox").innerHTML = this.responseText;
                checkNotifications();
            }
        };
        xhr.send("fetch_live_orders=1");
    }, 3000);

    function filterMenu(category, btn) {
        document.querySelectorAll('.category-badge').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.menu-item-col').forEach(card => {
            if(category === 'All' || card.dataset.category === category) card.style.display = 'block';
            else card.style.display = 'none';
        });
    }

    function addToCart(name, price) {
        if(!isTimeSelected) { 
            showTimeModal("Pickup Time Required", "Please select a pickup time before adding items to your cart.", null, null, null);
            document.getElementById('hourSelect').focus(); return; 
        }
        if (cart[name]) { cart[name].qty += 1; } else { cart[name] = { price: price, qty: 1 }; }
        updateCartUI();
        document.getElementById('toastMsg').innerText = name + ' added to cart!';
        const toastEl = new bootstrap.Toast(document.getElementById('cartToast'));
        toastEl.show();
    }

    function updateCartUI() {
        let count = 0; let total = 0;
        for (let item in cart) { count += cart[item].qty; total += cart[item].price * cart[item].qty; }
        document.getElementById('cartCount').innerText = count; document.getElementById('cartTotalBtn').innerText = total;
        document.getElementById('floatBtn').style.display = count > 0 ? 'block' : 'none';
    }

    function renderCart() {
        const list = document.getElementById('cartList'); list.innerHTML = ''; let total = 0; 
        if (Object.keys(cart).length === 0) {
            list.innerHTML = `<div class="text-center text-muted py-5 rounded empty-cart-box border border-dashed"><i class="fas fa-shopping-basket fa-3x mb-3 opacity-25"></i><p class="mb-0 fw-bold">Your cart is empty.</p></div>`;
            document.querySelector('button[name="place_order_final"]').disabled = true;
            document.getElementById('hidden_cart_json').value = "";
        } else {
            document.querySelector('button[name="place_order_final"]').disabled = false;
            for (let name in cart) {
                let item = cart[name]; let itemTotal = item.price * item.qty; total += itemTotal; 
                let safeName = name.replace(/'/g, "\\'");
                
                // GREEN DOT REMOVED FROM CART RENDER AS WELL
                list.innerHTML += `
                <li class="list-group-item d-flex justify-content-between align-items-center border-0 border-bottom pb-3 mb-2 px-0">
                    <div><div class="fw-bold text-dark">${name}</div><small class="text-muted">₹${item.price} x ${item.qty}</small></div>
                    <div class="d-flex align-items-center qty-controls rounded-pill px-1 border">
                        <button type="button" class="btn btn-sm text-danger fw-bold" onclick="updateQty('${safeName}', -1)"><i class="fas fa-minus"></i></button>
                        <span class="mx-2 fw-bold text-dark" style="width:20px; text-align:center;">${item.qty}</span>
                        <button type="button" class="btn btn-sm text-success fw-bold" onclick="updateQty('${safeName}', 1)"><i class="fas fa-plus"></i></button>
                    </div>
                    <span class="fw-bold text-dark">₹${itemTotal}</span>
                </li>`;
            }
        }
        document.getElementById('cartTotalModal').innerText = total; document.getElementById('hidden_total').value = total; 
        document.getElementById('hidden_cart_json').value = JSON.stringify(cart);
        if(document.getElementById('scheduleTime').value) { document.getElementById('hidden_time').value = document.getElementById('scheduleTime').value; }
    }

    function openCartModal() { renderCart(); new bootstrap.Modal(document.getElementById('cartModal')).show(); }

    function updateQty(name, change) {
        if (cart[name]) {
            cart[name].qty += change; if (cart[name].qty <= 0) { delete cart[name]; }
            updateCartUI(); renderCart();   
        }
    }

    function validateProfile() { return true; }

    function showFullScreenId(code) {
        document.getElementById('overlayOrderId').innerText = '#' + code;
        document.getElementById('fullScreenOverlay').style.display = 'flex';
        document.getElementById('fullScreenOverlay').classList.remove('rotate-screen');
    }
    
    const summaryModal = new bootstrap.Modal(document.getElementById('liveSummaryModal'));
    function showLiveSummary(code, items, total) {
        document.getElementById('ls_code').innerText = "Order #" + code;
        let formattedItems = "<div>" + items.replace(/, /g, "</div><div class='mt-1'>") + "</div>";
        document.getElementById('ls_items').innerHTML = formattedItems;
        document.getElementById('ls_total').innerText = total;
        summaryModal.show();
    }

    function closeFullScreen() { document.getElementById('fullScreenOverlay').style.display = 'none'; }
    function toggleLandscape() { document.getElementById('fullScreenOverlay').classList.toggle('rotate-screen'); }

    initTimeDropdowns();
</script>
</body>
</html>